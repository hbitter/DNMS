/*
 *	airRohr firmware
 *	Copyright (C) 2016-2018 Code for Stuttgart a.o.
 *
 *  English translations
 *
 *	Texts should be as short as possible
 */

#define INTL_LANG "EN"
#define INTL_PM_SENSOR "DNMS noise sensor"
const char INTL_CONFIGURATION[] PROGMEM = "Configuration";
#define INTL_WIFI_SETTINGS "WiFi Settings"
#define INTL_WIFI_WITH_PWD "With WLAN Password"
#define INTL_WIFI_NETWORKS "Loading wifi networks ..."
#define INTL_LANGUAGE "Language"
const char INTL_NO_NETWORKS[] PROGMEM =  "No WiFi Network Found";
const char INTL_NETWORKS_FOUND[] PROGMEM = "Found Networks: ";
const char INTL_AB_HIER_NUR_ANDERN[] PROGMEM = "Advanced settings (оnly if you know what you are doing)";
const char INTL_CAREFUL_ATTENTION[] PROGMEM = "Careful attention for changing I²C pins!";
const char INTL_SAVE[] PROGMEM = "Save";
const char INTL_SENSORS[] PROGMEM = "Sensors";
const char INTL_START[] PROGMEM = "After a restart:"
const char INTL_START_ZWEI[] PROGMEM = "Attention! Access to the local web server is not possible while waiting!:"
const char INTL_START_ON_FULL_MINUTE[] PROGMEM = "start measurements on the full minute";
const char INTL_START_ON_FULL_HOUR[] PROGMEM = "start measurements on the full hour";
const char INTL_SENSOR_CYCLIC_RESTART[] PROGMEM = "cyclic restart od sensor";
const char INTL_SENSOR_CYCLIC_RESTART_TIME[] PROGMEM = "time for resart in h";
const char INTL_DNMS_SENSOR[] PROGMEM = "DNMS noise sensor";
const char INTL_MORE_SENSORS[] PROGMEM = "More Sensors";
const char INTL_SDS011[] PROGMEM = "SDS011 ({pm})";
const char INTL_PMS[] PROGMEM = "Plantower PMS(1,3,5,6,7)003 ({pm})";
const char INTL_HPM[] PROGMEM = "Honeywell PM ({pm})";
const char INTL_NPM[] PROGMEM = "Tera Sensor Next PM ({pm})";
const char INTL_NPM_FULLTIME[] PROGMEM = "Next PM fulltime";
const char INTL_IPS[] PROGMEM = "IPS-7100 PM ({pm})";
const char INTL_SEN5X[] PROGMEM = "Sensirion SEN5X ({pm}, {t}, {h}, {voc}, {nox})";
const char INTL_SPS30[] PROGMEM = "Sensirion SPS30 ({pm})";
const char INTL_PPD42NS[] PROGMEM = "PPD42NS ({pm})";
const char INTL_DHT22[] PROGMEM = "DHT22 ({t}, {h})";
const char INTL_HTU21D[] PROGMEM = "HTU21D ({t}, {h})";
const char INTL_BMP180[] PROGMEM = "BMP180 ({t}, {p})";
const char INTL_BMX280[] PROGMEM = "BME280 ({t}, {h}, {p}), BMP280 ({t}, {p})";
const char INTL_SHT3X[] PROGMEM = "SHT3X ({t}, {h})";
const char INTL_SCD30[] PROGMEM = "SCD30 ({t}, {h}, CO₂)";
const char INTL_SCD4X[] PROGMEM = "SCD4X ({t}, {h}, CO₂)";
const char INTL_SCD4X_LOW_POWER[] PROGMEM = "SCD4X low power measurement";
const char INTL_DS18B20[] PROGMEM = "DS18B20 ({t})";
const char INTL_I2C_GPIO_SCL[] PROGMEM = "I²C SCL GPIO Pin";
const char INTL_I2C_GPIO_SDA[] PROGMEM = "I²C SDA GPIO Pin";
const char INTL_DNMS[] PROGMEM = "DNMS ({l_a})";
const char INTL_DNMS_Z[] PROGMEM = "DNMS ({l_z})";
const char INTL_DNMS_SPECTRUM[] PROGMEM = "DNMS frequency spectrum A-weighting";
const char INTL_DNMS_SPECTRUM_Z[] PROGMEM = "DNMS frequency spectrum Z-weighting";
const char INTL_DNMS_2nd_INTERVAL[] PROGMEM = "DNMS 2nd measurement interval (LAeq)";
const char INTL_DNMS_2nd_INTERVAL_Z[] PROGMEM = "DNMS 2nd measurement interval (LZeq)";
const char INTL_DNMS_2nd_SPECTRUM[] PROGMEM = "DNMS 2nd measurement interval frequency spectrum A-weighting";
const char INTL_DNMS_2nd_SPECTRUM_Z[] PROGMEM = "DNMS 2nd measurement interval frequency spectrum Z-weighting";
const char INTL_DNMS_2nd_INTERVAL_TIME[] PROGMEM = "DNMS 2nd measurement interval in seconds";
const char INTL_DNMS_2nd_THRESHOLD[] PROGMEM = "DNMS 2nd measurement LAeq threshold&nbsp;in&nbsp;dB(A)";
const char INTL_DNMS_2nd_NUMBER_MEASUREMENTS[] PROGMEM = "DNMS # of 2nd measurements after exceeding threshold";
const char INTL_DNMS_2nd_SWITCH_OUTPUT[] PROGMEM = "DNMS 2nd measurement switch output if threshold is exceeded";
const char INTL_DNMS_2nd_GPIO_PIN[] PROGMEM = "DNMS 2nd GPIO Pin to switch";
const char INTL_DNMS_CORRECTION[] PROGMEM = "DNMS correction in dB(A)";
const char INTL_DNMS_MICROPHONE[] PROGMEM = "Which microphone is connected to the DNMS sensor? (please tick only one)";
const char INTL_DNMS_ICS43434[] PROGMEM = "ICS-43434";
const char INTL_DNMS_IM72D128[] PROGMEM = "IM72D128";
const char INTL_TEMP_CORRECTION[] PROGMEM = "Correction in °C";
const char INTL_HEIGHT_ABOVE_SEALEVEL[] PROGMEM = "Above sea level (m)";
const char INTL_PRESSURE_AT_SEALEVEL[] PROGMEM = "pressure at sea level";
const char INTL_NEO6M[] PROGMEM = "GPS (NEO 6M)";
const char INTL_BASICAUTH[] PROGMEM = "Authentication";
#define INTL_REPORT_ISSUE "Report an issue"

const char INTL_FS_WIFI_DESCRIPTION[] PROGMEM = "WiFi Sensor in configuration mode";
const char INTL_FS_WIFI_NAME[] PROGMEM = "Network name";
const char INTL_MORE_SETTINGS[] PROGMEM = "More settings";
const char INTL_AUTO_UPDATE[] PROGMEM = "Auto update firmware";
const char INTL_USE_BETA[] PROGMEM = "Load beta firmware";
const char INTL_DISPLAY[] PROGMEM = "OLED SSD1306";
const char INTL_SH1106[] PROGMEM = "OLED SH1106";
const char INTL_FLIP_DISPLAY[] PROGMEM = "OLED display flip";
const char INTL_LCD1602_27[] PROGMEM = "LCD 1602 (I2C: 0x27)";
const char INTL_LCD1602_3F[] PROGMEM = "LCD 1602 (I2C: 0x3F)";
const char INTL_LCD2004_27[] PROGMEM = "LCD 2004 (I2C: 0x27)";
const char INTL_LCD2004_3F[] PROGMEM = "LCD 2004 (I2C: 0x3F)";
const char INTL_DISPLAY_WIFI_INFO[] PROGMEM = "Display Wifi info";
const char INTL_DISPLAY_DEVICE_INFO[] PROGMEM = "Display device info";
const char INTL_POWERSAVE [] PROGMEM ="Powersave?";

#define INTL_STATIC_IP_TEXT "Configuration static IP address (all fields must be completed)"
const char INTL_STATIC_IP[] PROGMEM = "IP address";
const char INTL_STATIC_SUBNET[] PROGMEM = "Subnet";
const char INTL_STATIC_GATEWAY[] PROGMEM = "Gateway";
const char INTL_STATIC_DNS[] PROGMEM = "DNS server";
const char INTL_NTP_SERVER_1[] PROGMEM = "NTP server 1";
const char INTL_NTP_SERVER_2[] PROGMEM = "NTP server 2";
const char INTL_NTP_SERVER_TEXT[] PROGMEM = "NTP server change";

const char INTL_DEBUG_LEVEL[] PROGMEM = "Debug&nbsp;level";
const char INTL_MEASUREMENT_INTERVAL[] PROGMEM = "Measuring interval (sec)";
const char INTL_DURATION_ROUTER_MODE[] PROGMEM = "Duration router mode";
const char INTL_MORE_APIS[] PROGMEM = "More APIs";
const char INTL_SEND_TO_OWN_API[] PROGMEM = "Send data to custom API";
const char INTL_SERVER[] PROGMEM = "Server";
const char INTL_PATH[] PROGMEM = "Path";
const char INTL_PORT[] PROGMEM = "Port";
const char INTL_USER[] PROGMEM = "User";
const char INTL_PASSWORD[] PROGMEM = "Password";
const char INTL_MQTT_MEASUREMENT[] PROGMEM = "MQTT measurement";
const char INTL_MQTT_MAIN_TOPIC[] PROGMEM = "MQTT main topic";
const char INTL_ID_AS_MQTT_SUB_TOPIC[] PROGMEM = "Sensor ID as MQTT sub topic";
const char INTL_INFLUX_MEASUREMENT[] PROGMEM = "Measurement";
const char INTL_SEND_TO[] PROGMEM = "Send to {v}";
const char INTL_READ_FROM[] PROGMEM = "Read from {v}";
const char INTL_SENSOR_IS_REBOOTING[] PROGMEM = "Sensor is rebooting.";
const char INTL_RESTART_DEVICE[] PROGMEM = "Restart device";
const char INTL_DELETE_CONFIG[] PROGMEM = "delete saved configuration";
const char INTL_RESTART_SENSOR[] PROGMEM = "Restart sensor";
#define INTL_HOME "Home"
#define INTL_BACK_TO_HOME "Back to home page"
const char INTL_CURRENT_DATA[] PROGMEM = "Current data";
const char INTL_DEVICE_STATUS[] PROGMEM = "Device status";
#define INTL_ACTIVE_SENSORS_MAP "Active sensors map (external link)"
#define INTL_CONFIGURATION_DELETE "Delete configuration"
#define INTL_CONFIGURATION_REALLY_DELETE "Are you sure you want to delete the configuration?"
#define INTL_DELETE "Delete"
#define INTL_CANCEL "Cancel"
#define INTL_REALLY_RESTART_SENSOR "Are you sure you want to restart the sensor?"
#define INTL_RESTART "Restart"
const char INTL_SAVE_AND_RESTART[] PROGMEM = "Save configuration and restart";
#define INTL_FIRMWARE "Firmware version"
const char INTL_DEBUG_SETTING_TO[] PROGMEM = "Set debug level to";
#define INTL_NONE "off"
#define INTL_ERROR "only errors"
#define INTL_WARNING "warnings"
#define INTL_MIN_INFO "min. info"
#define INTL_MED_INFO "mid. info"
#define INTL_MAX_INFO "max. info"
#define INTL_CONFIG_DELETED "Configuration was deleted"
#define INTL_CONFIG_CAN_NOT_BE_DELETED "Configuration can not be deleted"
#define INTL_CONFIG_NOT_FOUND "Configuration not found"
const char INTL_TIME_TO_FIRST_MEASUREMENT[] PROGMEM = "Still {v} seconds until first measurement (1st measurement interval).";
const char INTL_TIME_SINCE_LAST_MEASUREMENT[] PROGMEM = " seconds since last measurement (1st measurement interval).";
const char INTL_PARTICLES_PER_LITER[] PROGMEM = "particles/liter";
const char INTL_PARTICULATE_MATTER[] PROGMEM = "particulate matter";
const char INTL_TEMPERATURE[] PROGMEM = "temperature";
const char INTL_HUMIDITY[] PROGMEM = "humidity";
const char INTL_PRESSURE[] PROGMEM = "air pressure";
const char INTL_VOC[] PROGMEM = "Volatile organic compound";
const char INTL_NOX[] PROGMEM = "Nitrogen oxides";
const char INTL_DEW_POINT[] PROGMEM = "dew point";
const char INTL_CO2_PPM[] PROGMEM = "ppm CO₂";
const char INTL_LEQ_A[] PROGMEM = "LAeq";
const char INTL_LA_MIN[] PROGMEM = "LA min";
const char INTL_LA_MAX[] PROGMEM = "LA max";
const char INTL_LEQ_Z[] PROGMEM = "LZeq";
const char INTL_LZ_MIN[] PROGMEM = "LZ min";
const char INTL_LZ_MAX[] PROGMEM = "LZ max";
const char INTL_LEQ_A_2nd[] PROGMEM = "LAeq_2nd";
const char INTL_LA_MIN_2nd[] PROGMEM = "LA min_2nd";
const char INTL_LA_MAX_2nd[] PROGMEM = "LA max_2nd";
const char INTL_LEQ_Z_2nd[] PROGMEM = "LZeq_2nd";
const char INTL_LZ_MIN_2nd[] PROGMEM = "LZ min_2nd";
const char INTL_LZ_MAX_2nd[] PROGMEM = "LZ max_2nd";
const char INTL_LATITUDE[] PROGMEM = "Latitude";
const char INTL_LONGITUDE[] PROGMEM = "Longitude";
const char INTL_ALTITUDE[] PROGMEM = "Altitude";
const char INTL_TIME_UTC[] PROGMEM = "Time (UTC) ";
const char INTL_SIGNAL_STRENGTH[] PROGMEM = "signal strength";
const char INTL_SIGNAL_QUALITY[] PROGMEM = "signal quality";
#define INTL_NUMBER_OF_MEASUREMENTS "Number of measurements"
#define INTL_TIME_SENDING_MS "Time spent uploading"
#define INTL_SENSOR "Sensor"
#define INTL_PARAMETER "Parameter"
#define INTL_VALUE "Value"

#include "./airrohr-logo-common.h"
