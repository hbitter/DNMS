#ifndef intl_h
#define intl_h

// set language of local webserver

#include "intl_de.h"
//#include "intl_en.h"
//#include "intl_fr.h"


#endif
