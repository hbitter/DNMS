#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>



char *b64_encode(const unsigned char *in, size_t len);
