/*
 *  raspi-dnms
 *  
 *  Raspi program for noise measurement with a connected DNMS sensor
 *  It works from Zero W up to Raspi 4
 * 
 *  Program sends measurement to Sensor.Community and/or to an influxDB.
 *  Besides the fixed measurement interval of Sensor.Community (150 s) a 2nd measurement interval 
 *  for the influxDB is supported. The interval time of the 2nd measurement interval can be freely configured (1 - 3600 s).
 *  Transmission of data can be configured as http or https transmission.
 *                                                                      
 *  Copyright (C) 2022, 2023, 2024  Helmut Bitter
 *                                                                      
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *                                                                      
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *                                                                      
 *  You should have received a copy of the GNU General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/>.
 * 
 */

// if defined, than you can switch a gpio pin if a certain noise level is exceeded. The pigpio lib is includes and you have to start dnms with sudo (that depends on the pigpio lib)
// if you don't want to switch a gpio pin comment the define  gpio_switch out
#define gpio_switch false

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <sys/time.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/bio.h>
#include <sys/socket.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <unistd.h>
#include <libconfig.h>
#include <mosquitto.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "./dnms_rpi_i2c.h"
#include "./b64_encode.h"
#include "./data_logging.h"


#ifdef gpio_switch
#include <pigpio.h>
#endif


const char firmware_version[] = { "raspi-dnms-0.9.21" };  // Firmware Version for Raspberry Pi

config_t cfg;
config_setting_t *setting;


/* *************************************   start configuration values   ********************************************** */
// waiting time after program start - this depends on the raspi type, Pi Zero W should be 20 seconds, for Pi Zero 2W 10 seconds
int waiting_time_after_start;
// Priorities for threads
int prio_1st_timer;
int prio_1st_measurement;
int prio_2nd_timer;
int prio_2nd_measurement;
int prio_wlan;
int prio_print_ipc_and_log_1st;
int prio_print_ipc_and_log_2nd;
int prio_start_stop;

const char *dev_name_dnms;   // name of I²C device on Raspi
const char *interface_name;  // name of wlan or lan interface for transmission of data to Sensor.Community and/or other APIs
int enable_wlan_or_lan;      // enabble wlan or lan for transmission to Sensor.Community and/or InfluxDB


/* ********* Configuration of connected microphone  -- ICS-43434  or IM72D128  *********  */
const char *dnms_microphone;  // which microphone is connected?

/* ********* Correction value in dB for microphone for time domain dB(A) an dB(Z) values  -- for ICS-43434  or IM72D128  *********  */
double dnms_correction;

/* ********* Configuration of intervals for 1st and 2nd measurements ********* */
int enable_1st_interval;                   // enable or disable 1st measurement
int measurement_1st_interval_ms;           // 1st measurement interval, in ms
int enable_2nd_interval;                   // enable or disable 2nd measurement
int measurement_2nd_interval_ms;           // 2nd measurement interval, in ms
int threshold_2nd_interval_laeq_transmit;  // threshold for transmission of 2nd interval measurements to influxdb, transmission to influxdb is started if LAeq is equal or higher than threshold
int number_transmissions_after_exceeding;  // number of transmissions of 2nd interval measurement after exceeding threshold
int switch_output_pin;                     // switch output pin, if threshold of 2nd is exceeded, true or false
int gpio_output_pin;                       // pin that is switched on/off based on Broadcom GPIO numbering
int start_on_full_minute;                  // start measurements on the full minute (seconds = 00)
int start_on_full_hour;                    // start measurements on the full hour (minutes = 00 and seconds = 00)
int time_correction;                       // coorection in microseconds for intervall time


/* *********  Configuration options what data is tranferred to InfluxDB/MQTT Broker *********  */
int data_transmit_laeq_1st_to_influxdb;           // 1st measurement interval LAeq data to influxDB, true or false
int data_transmit_lzeq_1st_to_influxdb;           // 1st measurement interval LZeq data to influxDB, true or false
int data_transmit_laeq_1st_spectrum_to_influxdb;  // 1st measurement interval spectrum LAeq data to influxDB, true or false
int data_transmit_lzeq_1st_spectrum_to_influxdb;  //  1st measurement interval spectrum LZeq data to influxDB, true or false
int data_transmit_laeq_2nd_to_influxdb;           // 2nd measurement interval LAeq data to influxDB, true or false
int data_transmit_lzeq_2nd_to_influxdb;           // 2nd measurement interval LZeq data to influxDB, true or false
int data_transmit_laeq_2nd_spectrum_to_influxdb;  // 2nd measurement interval LAeq spectrum data to influxDB, true or false
int data_transmit_lzeq_2nd_spectrum_to_influxdb;  // 2nd measurement interval LZeq spectrum data to influxDB, true or false
int timestamp_to_influxdb;                        // send timestamp to InfluxDB, true or fase
int influxdb_transmit_http;                       // data transmission to influxDB as http, true or false (false means no http transmission)
int influxdb_transmit_https;                      // data transmission to InfluxDB as https, true or false (false means no https transmission)
int influxdb_version_2;                           // Support of InfluxDB version 2, true or false, at the moment only version 1.8 is supported
const char *influxdb_server;                      // InfluxDB server address
const char *influxdb_port;                        // InfluxDB server port
const char *influxdb_pfad;                        // InfluxDB database path and name
const char *influxdb_user;                        // InfluxDB user name
const char *influxdb_passwort;                    // InfluxDB passwort for user
const char *influxdb_messung;                     // InfluxDB measurement name

/* *********  Configuration options for transmission to MQTT Broker  *********  */
int mqtt_transmit;             // data transmission to MQTT Broker, InfluxDB Line Protocol is used, true or false (false means no http transmission)
const char *mqtt_user;         // MQTT user name
const char *mqtt_passwort;     // MQTT user passwort
const char *mqtt_broker;       // URL of MQRR Broker
int mqtt_port;                 // Port for MQTT Broker connection
int mqtt_keepalive;            // MQTT keepalive time
int mqtt_qos;                  // MQTT QoS
const char *mqtt_main_topic;   // MQTT Main Topic
int mqtt_use_id_as_sub_topic;  // use the Raspberry ID as MQTT Sub Topic


/* ********* Configuration options for transmission to Sensor.Community *********  */
int data_transmit_laeq_to_sc;  // transmission of LAeq 1st interval to Sensor.Community, true or false
const char *host_sc;           // Host Sensor.Community
const char *port_sc;           // Port Sensor.Community and http or https  -- Attention: At the moment https is not working, you have to use http
const char *url_sc;            // URL to data store of Sensor.Community
const char *DNMS_API_PIN;      // API PIN für DNMS at Sensor.Community
int sc_transmit_https;         // use http or https for transmission to Sensor.Community, must be inline with port_sc and: At them moment https is not working,
                               // you have to use http, true or false

/* ********* Configuration options for IPC - Inter Process Communication  using a named pipe ********* */
int data_transmit_via_pipe;
const char *name_of_pipe;


/*  ********* start/stop measurement from named pipe message  ********* */
const char *start_stop_name_of_pipe;  // name of named pipe for start/stop
int start_stop_extern;                // enable or disable external start/stop functionality (true =enable, false = disable)


/* ********* output of mesurement  values on terminal *********  */
int data_on_terminal;


/* ********* which mesurement values are outputed on terminal, named pipe or data logging *********  */
int data_laeq_1st_output_on_terminal;             // output of LAeq 1st interval measurements values on terminal, true or false
int data_la_spec_1st_output_on_terminal;          // output of LA spectrum 1st interval measurements values on terminal, true or false
int data_lzeq_1st_output_on_terminal;             // output of LZeq 1st interval measurements values on terminal, true or false
int data_lz_spec_1st_output_on_terminal;          // output of LZ spectrum 1st interval measurements values on terminal, true or false
int data_laeq_2nd_output_on_terminal;             // output of LAeq 2nd interval measurements values on terminal, true or false
int data_la_spec_2nd_output_on_terminal;          // output of LA spectrum 2nd interval measurements values on terminal, true or false
int data_lzeq_2nd_output_on_terminal;             // output of LZeq 2nd interval measurements values on terminal, true or false
int data_lz_spec_2nd_output_on_terminal;          // output of LZ spectrum 2nd interval measurements values on terminal, true or false
int last_influxdb_transmission_time_to_terminal;  // output to terminal of last transmission time to InfluxDB, true or false
int threshold_output_influxdb_ltt_to_terminal;    // threshold to output the last transmission time to InfluxDB to terminal if transmission time is higher than threshold, in ms
int last_sc_transmission_time_to_terminal;        // output to terminal of last transmission time to Sensor.Community, true or false
int threshold_output_sc_ltt_to_terminal;          // threshold to output last transmission time to influxdb to terminal if transmission time is higher than threshold, in ms
int output_thread_info;                           // output of thread information at program start


/* ********* data logging functionality ********* */
int data_logging;                    // enable/diasable data logging functionality
const char *data_logging_directory;  // directory for data logging (full path)

/* *************************************   end configuration values   ******************************************************* */


#define msg_size 2048
#define timestamp_size 32
#define log_size 256
#define number_of_mac_loops 20

#define buffer_fail -1
#define buffer_success 0
#define buffer_size_sc 4
#define buffer_size_influx 512
#define dest_influxdb 2
#define dest_sc 1

bool transmission_enabled = true;  // transmission takes place only if flag "transmission_enabled" is set to true

bool interval_1st_active = false;   // 1st measurement interval active
bool interval_2nd_active = false;   // 2nd measurement interval active if available/supported by DNMS firmware
uint16_t counter_threshold_2nd;     // counter for number of transmissions to InfluxDB after exceeding trhreshold
bool data_to_influxdb = false;      // will be set to true if data has to be transmitted to InfluxDB
bool data_1st_to_influxdb = false;  // will be set to true if 1st measurement data has to be transmitted to InfluxDB
bool data_2nd_to_influxdb = false;  // will be set to true if 2nd measurement data has to be transmitted to InfluxDB

unsigned char mac_adr[6];
char mac_strg[13];
int raspi_id;
char raspi_id_strg[16];

char influxdb_hostname[64];
char influxdb_user_passwd[64];
char *encoded_user_passwd;
char sc_hostname[64];

char msg[msg_size];
char send_data[msg_size];
char send_data_mqtt[msg_size];

struct Ring_Buffer_sc {
  char b_data[buffer_size_sc][msg_size];
  char b_timestamp[buffer_size_sc][timestamp_size];
  long int b_last_tt[buffer_size_sc];      // last transmission time
  uint16_t b_destination[buffer_size_sc];  // destination of data: 1 = Sensor.Community, 2 = influxDB - has to be set explicitly
  uint16_t b_read;                         // pointer to last data
  uint16_t b_write;                        // pointer to next free buffer element
} buffer_sc = { { {}, {} }, { {}, {} }, {}, {}, 0, 0 };

struct Ring_Buffer_influx {
  char b_data[buffer_size_influx][msg_size];
  char b_timestamp[buffer_size_influx][timestamp_size];
  long int b_last_tt[buffer_size_influx];      // last transmission time
  uint16_t b_destination[buffer_size_influx];  // destination of data: 1 = Sensor.Community, 2 = influxDB - has to be set explicitly
  uint16_t b_read;                             // pointer to last data
  uint16_t b_write;                            // pointer to next free buffer element
} buffer_influx = { { {}, {} }, { {}, {} }, {}, {}, 0, 0 };

char msg_header1[256];
char msg_header2[256];
char msg_header3[] = { "\r\n\r\n" };

char sc_header1[512];
char sc_header2[] = { "\r\n\r\n" };
char sc_msg[1024];

uint16_t length_data_str;
uint16_t length_data_sc_str;
long unsigned int output_size;
char str_of_length_data_str[4];
char str_of_length_data_sc_str[4];

char timestamp_4_log_A_1st[log_size];
char timestamp_4_log_Z_1st[log_size];
char timestamp_4_log_A_2nd[log_size];
char timestamp_4_log_Z_2nd[log_size];
char print_string_1st[log_size];
char part_string_1st[log_size];
char print_string_2nd[log_size];
char part_string_2nd[log_size];
char data_4_transmit[msg_size];
char data_4_influxdb_2nd[msg_size];
char value_2_string[16];
char value_2_string_2nd[16];
char value_2_string_wlan[16];

char data_sc_1[128];
char data_sc_2[128];
char data_sc_3[64];
char data_sc_4[16];

char terzen[31][23] = {
  ",DNMS_noise_LAeq20=", ",DNMS_noise_LAeq25=", ",DNMS_noise_LAeq31.5=", ",DNMS_noise_LAeq40=",
  ",DNMS_noise_LAeq50=", ",DNMS_noise_LAeq63=", ",DNMS_noise_LAeq80=", ",DNMS_noise_LAeq100=", ",DNMS_noise_LAeq125=",
  ",DNMS_noise_LAeq160=", ",DNMS_noise_LAeq200=", ",DNMS_noise_LAeq250=", ",DNMS_noise_LAeq315=",
  ",DNMS_noise_LAeq400=", ",DNMS_noise_LAeq500=", ",DNMS_noise_LAeq630=", ",DNMS_noise_LAeq800=",
  ",DNMS_noise_LAeq1000=", ",DNMS_noise_LAeq1250=", ",DNMS_noise_LAeq1600=", ",DNMS_noise_LAeq2000=",
  ",DNMS_noise_LAeq2500=", ",DNMS_noise_LAeq3150=", ",DNMS_noise_LAeq4000=", ",DNMS_noise_LAeq5000=",
  ",DNMS_noise_LAeq6300=", ",DNMS_noise_LAeq8000=", ",DNMS_noise_LAeq10000=", ",DNMS_noise_LAeq12500=",
  ",DNMS_noise_LAeq16000=", ",DNMS_noise_LAeq20000="
};
char terzen_z[31][23] = {
  ",DNMS_noise_LZeq20=", ",DNMS_noise_LZeq25=", ",DNMS_noise_LZeq31.5=", ",DNMS_noise_LZeq40=",
  ",DNMS_noise_LZeq50=", ",DNMS_noise_LZeq63=", ",DNMS_noise_LZeq80=", ",DNMS_noise_LZeq100=", ",DNMS_noise_LZeq125=",
  ",DNMS_noise_LZeq160=", ",DNMS_noise_LZeq200=", ",DNMS_noise_LZeq250=", ",DNMS_noise_LZeq315=",
  ",DNMS_noise_LZeq400=", ",DNMS_noise_LZeq500=", ",DNMS_noise_LZeq630=", ",DNMS_noise_LZeq800=",
  ",DNMS_noise_LZeq1000=", ",DNMS_noise_LZeq1250=", ",DNMS_noise_LZeq1600=", ",DNMS_noise_LZeq2000=",
  ",DNMS_noise_LZeq2500=", ",DNMS_noise_LZeq3150=", ",DNMS_noise_LZeq4000=", ",DNMS_noise_LZeq5000=",
  ",DNMS_noise_LZeq6300=", ",DNMS_noise_LZeq8000=", ",DNMS_noise_LZeq10000=", ",DNMS_noise_LZeq12500=",
  ",DNMS_noise_LZeq16000=", ",DNMS_noise_LZeq20000="
};

char terzen_2nd[31][27] = {
  ",DNMS_noise_LAeq20_2nd=", ",DNMS_noise_LAeq25_2nd=", ",DNMS_noise_LAeq31.5_2nd=", ",DNMS_noise_LAeq40_2nd=",
  ",DNMS_noise_LAeq50_2nd=", ",DNMS_noise_LAeq63_2nd=", ",DNMS_noise_LAeq80_2nd=", ",DNMS_noise_LAeq100_2nd=", ",DNMS_noise_LAeq125_2nd=",
  ",DNMS_noise_LAeq160_2nd=", ",DNMS_noise_LAeq200_2nd=", ",DNMS_noise_LAeq250_2nd=", ",DNMS_noise_LAeq315_2nd=",
  ",DNMS_noise_LAeq400_2nd=", ",DNMS_noise_LAeq500_2nd=", ",DNMS_noise_LAeq630_2nd=", ",DNMS_noise_LAeq800_2nd=",
  ",DNMS_noise_LAeq1000_2nd=", ",DNMS_noise_LAeq1250_2nd=", ",DNMS_noise_LAeq1600_2nd=", ",DNMS_noise_LAeq2000_2nd=",
  ",DNMS_noise_LAeq2500_2nd=", ",DNMS_noise_LAeq3150_2nd=", ",DNMS_noise_LAeq4000_2nd=", ",DNMS_noise_LAeq5000_2nd=",
  ",DNMS_noise_LAeq6300_2nd=", ",DNMS_noise_LAeq8000_2nd=", ",DNMS_noise_LAeq10000_2nd=", ",DNMS_noise_LAeq12500_2nd=",
  ",DNMS_noise_LAeq16000_2nd=", ",DNMS_noise_LAeq20000_2nd="
};
char terzen_z_2nd[31][27] = {
  ",DNMS_noise_LZeq20_2nd=", ",DNMS_noise_LZeq25_2nd=", ",DNMS_noise_LZeq31.5_2nd=", ",DNMS_noise_LZeq40_2nd=",
  ",DNMS_noise_LZeq50_2nd=", ",DNMS_noise_LZeq63_2nd=", ",DNMS_noise_LZeq80_2nd=", ",DNMS_noise_LZeq100_2nd=", ",DNMS_noise_LZeq125_2nd=",
  ",DNMS_noise_LZeq160_2nd=", ",DNMS_noise_LZeq200_2nd=", ",DNMS_noise_LZeq250_2nd=", ",DNMS_noise_LZeq315_2nd=",
  ",DNMS_noise_LZeq400_2nd=", ",DNMS_noise_LZeq500_2nd=", ",DNMS_noise_LZeq630_2nd=", ",DNMS_noise_LZeq800_2nd=",
  ",DNMS_noise_LZeq1000_2nd=", ",DNMS_noise_LZeq1250_2nd=", ",DNMS_noise_LZeq1600_2nd=", ",DNMS_noise_LZeq2000_2nd=",
  ",DNMS_noise_LZeq2500_2nd=", ",DNMS_noise_LZeq3150_2nd=", ",DNMS_noise_LZeq4000_2nd=", ",DNMS_noise_LZeq5000_2nd=",
  ",DNMS_noise_LZeq6300_2nd=", ",DNMS_noise_LZeq8000_2nd=", ",DNMS_noise_LZeq10000_2nd=", ",DNMS_noise_LZeq12500_2nd=",
  ",DNMS_noise_LZeq16000_2nd=", ",DNMS_noise_LZeq20000_2nd="
};


pthread_t measurement_1st_interval_thread;
pthread_t measurement_1st_interval_timer_thread;
pthread_t measurement_2nd_interval_thread;
pthread_t measurement_2nd_interval_timer_thread;
pthread_t print_ipc_and_log_1st_thread;
pthread_t print_ipc_and_log_2nd_thread;
pthread_t wlan_thread;
pthread_t start_stop_thread;

pthread_cond_t new_data_1st_cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t new_data_1st_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t new_1st_measurement_cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t new_1st_measurement_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t new_data_2nd_cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t new_data_2nd_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t new_2nd_measurement_cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t new_2nd_measurement_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t buffer_sc_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t buffer_influx_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t dnms_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t print_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t start_1st_measurement_cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t start_1st_measurement_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t start_2nd_measurement_cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t start_2nd_measurement_mutex = PTHREAD_MUTEX_INITIALIZER;

char *measurement_2nd_message = (char *)"measurement_2nd_interval_thread is up";
char *print_ipc_and_log_1st_message = (char *)"print ipc and_log 1st thread is up";
char *print_ipc_and_log_2nd_message = (char *)"print ipc and log 2nd thread is up";
char *measurement_2nd_timer_message = (char *)"measurement 2nd_interval_timer_thread is up";
char *wlan_message = (char *)"wlan_thread is up";
char *start_stop_message = (char *)"start_stop_thread is up";
char *measurement_1st_message = (char *)"measurement 1st_interval_thread is up";
char *measurement_1st_timer_message = (char *)"measurement 1st_interval_timer_thread is up";
int16_t i_measurement_1st_interval_thread;
int16_t i_measurement_1st_interval_timer_thread;
int16_t i_measurement_2nd_interval_thread;
int16_t i_measurement_2nd_interval_timer_thread;
int16_t i_print_ipc_and_log_1st_thread;
int16_t i_print_ipc_and_log_2nd_thread;
int16_t i_wlan_thread;
int16_t i_start_stop_thread;

void *measurement_2nd_interval_function(void *ptr);
void *measurement_2nd_interval_timer_function(void *ptr);
void *print_ipc_and_log_1st_function(void *ptr);
void *print_ipc_and_log_2nd_function(void *ptr);
void *wlan_function(void *ptr);
void *measurement_1st_interval_function(void *ptr);
void *measurement_1st_interval_timer_function(void *ptr);
void *start_stop_function(void *ptr);

char dnms_version[DNMS_MAX_VERSION_LEN + 1];
uint16_t data_ready;
uint16_t data_ready_2nd;
bool dnms_error = false;
bool dnms_error_2nd = false;
struct dnms_measurements dnms_values;
float last_value_dnms_laeq = 0.0;
float last_value_dnms_lamin = 0.0;
float last_value_dnms_lamax = 0.0;
float last_value_dnms_spectrum[31] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                       0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                       0.0 };
float last_value_dnms_laeq_2nd = 0.0;
float last_value_dnms_lamin_2nd = 0.0;
float last_value_dnms_lamax_2nd = 0.0;
float last_value_dnms_spectrum_2nd[31] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                           0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                           0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                           0.0 };

float last_value_dnms_lzeq = 0.0;
float last_value_dnms_lzmin = 0.0;
float last_value_dnms_lzmax = 0.0;
float last_value_dnms_z_spectrum[31] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                         0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                         0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                         0.0 };
float last_value_dnms_lzeq_2nd = 0.0;
float last_value_dnms_lzmin_2nd = 0.0;
float last_value_dnms_lzmax_2nd = 0.0;
float last_value_dnms_z_spectrum_2nd[31] = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                             0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                             0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                                             0.0 };

struct timeval tv;
struct timeval tv_1st;
struct timeval tv_2nd;
struct timeval mqtt_error_tv;
unsigned long long ns_mqtt;
unsigned long long ns_1st;
unsigned long long ns_2nd;
char t_string_1st[80];
char t_string_2nd[80];

char print_and_log_1st_A_buf[256];
char print_and_log_1st_Z_buf[256];
char print_and_log_2nd_A_buf[256];
char print_and_log_2nd_Z_buf[256];

struct timezone tz;

time_t time_wlan;
time_t time_print_1;
time_t time_print_2;
struct tm *ts_wlan;
struct tm *ts_print_1;
struct tm *ts_print_2;
struct tm *ts_mqtt_1;
struct tm *ts_mqtt_2;
time_t sekunden;
time_t minuten;
time_t rawtime_1st;
time_t rawtime_2nd;
time_t rawtime_mqtt;
char zeit_string_mqtt[80];
char zeit_string_print[80];
char zeit_string_wlan[80];
char timestamp_1st[timestamp_size];
char timestamp_2nd[timestamp_size];
char send_timestamp[timestamp_size];
long int send_last_tt;
uint16_t destination;

char mqtt_error_timestamp[timestamp_size];

struct timeval t0, t1, t2;
long long elapsedTime;
long int last_sc_transmission_time;
long int last_influxdb_transmission_time;

SSL_CTX *ctx;
SSL *ssl;
BIO *bio;
const SSL_METHOD *method;

char name[128];

bool print_flag = false;

struct mosquitto *mosq;
int rc;
char mqtt_topic[128];

int dnms_pipe_fd;
int start_stop_pipe_fd;
#define start_stop_buffer_size 256
char start_stop_buffer[start_stop_buffer_size];

char data_logging_file_name[64];


void open_dnms(void) {
  int ret;

  printf("Open i2c bus: ");
  if ((ret = open_i2c_dnms((char *)dev_name_dnms)) == 0) {
    printf("OK\n\n");
  } else {
    printf("Error open I²C return:, %3d\n", ret);
  }
  /* Reset DNMS Sensor */
  printf("Reset DNMS: ");
  if (dnms_reset() == 0) {
    printf("OK\n");
  } else {
    printf("Error reset DNMS, check it!\n");
  }
}

void close_dnms(void) {
  if (close_i2c_dnms() == 0) {
    // nothing to do
  } else {
    printf("Error closing i2c connection to DNMS!\n");
  }
}


int buffer_in_sc(char *msg, char *timestamp, uint16_t dest) {
  if ((buffer_sc.b_write + 1 == buffer_sc.b_read) || (buffer_sc.b_read == 0 && buffer_sc.b_write + 1 == buffer_size_sc)) {
    printf("buffer_in_sc: error buffer full!\n");
    exit(-1);
    pthread_mutex_unlock(&buffer_sc_mutex);
    return buffer_fail;  // buffer full
  }
  strcpy(buffer_sc.b_data[buffer_sc.b_write], msg);
  if (dest == dest_influxdb) {
    strcpy(buffer_sc.b_timestamp[buffer_sc.b_write], timestamp);
  }
  buffer_sc.b_destination[buffer_sc.b_write] = dest;

  buffer_sc.b_write++;
  if (buffer_sc.b_write >= buffer_size_sc) {
    buffer_sc.b_write = 0;
  }

  return buffer_success;
}


int buffer_out_sc(char *msg, char *timestamp, long int *last_tt, uint16_t *dest) {
  uint16_t d;

  if (buffer_sc.b_read == buffer_sc.b_write) {
    pthread_mutex_unlock(&buffer_sc_mutex);
    return buffer_fail;  // buffer empty
  }
  strcpy(msg, buffer_sc.b_data[buffer_sc.b_read]);
  d = buffer_sc.b_destination[buffer_sc.b_read];
  *dest = d;

  if (d == dest_influxdb)  // is destination influxdb, than get the timestamp is
  {
    strcpy(timestamp, buffer_sc.b_timestamp[buffer_sc.b_read]);
  }
  *last_tt = buffer_sc.b_last_tt[buffer_sc.b_read];
  buffer_sc.b_read++;
  if (buffer_sc.b_read >= buffer_size_sc) {
    buffer_sc.b_read = 0;
  }

  return buffer_success;
}


int buffer_in_influx(char *msg, char *timestamp, uint16_t dest) {
  if ((buffer_influx.b_write + 1 == buffer_influx.b_read) || (buffer_influx.b_read == 0 && buffer_influx.b_write + 1 == buffer_size_influx)) {
    printf("buffer_in_influx: error buffer full!\n");
    exit(-1);
    pthread_mutex_unlock(&buffer_influx_mutex);
    return buffer_fail;  // buffer full
  }
  strcpy(buffer_influx.b_data[buffer_influx.b_write], msg);
  if (dest == dest_influxdb) {
    strcpy(buffer_influx.b_timestamp[buffer_influx.b_write], timestamp);
  }
  buffer_influx.b_destination[buffer_influx.b_write] = dest;

  buffer_influx.b_write++;
  if (buffer_influx.b_write >= buffer_size_influx) {
    buffer_influx.b_write = 0;
  }

  return buffer_success;
}

void buffer_in_influx_last_tt(long int last_tt) {
  buffer_influx.b_last_tt[buffer_influx.b_read] = last_tt;
}

int buffer_out_influx(char *msg, char *timestamp, long int *last_tt, uint16_t *dest) {
  uint16_t d;

  if (buffer_influx.b_read == buffer_influx.b_write) {
    pthread_mutex_unlock(&buffer_influx_mutex);
    return buffer_fail;  // buffer empty
  }
  strcpy(msg, buffer_influx.b_data[buffer_influx.b_read]);
  d = buffer_influx.b_destination[buffer_influx.b_read];
  *dest = d;

  if (d == dest_influxdb)  // is destination influxdb, than get the timestamp is
  {
    strcpy(timestamp, buffer_influx.b_timestamp[buffer_influx.b_read]);
  }
  *last_tt = buffer_influx.b_last_tt[buffer_influx.b_read];
  buffer_influx.b_read++;
  if (buffer_influx.b_read >= buffer_size_influx) {
    buffer_influx.b_read = 0;
  }

  return buffer_success;
}

/* Callback called when the client receives a CONNACK message from the broker. */
void on_mqtt_connect(struct mosquitto *mosq, void *obj, int reason_code) {
  /* Print out the connection result. mosquitto_connack_string() produces an
	 * appropriate string for MQTT v3.x clients, the equivalent for MQTT v5.0
	 * clients is mosquitto_reason_string().
	 */
  //	printf("MQTT on_connect: %s\n", mosquitto_connack_string(reason_code));
  if (reason_code != 0) {
    /* If the connection fails for any reason, we don't want to keep on
		 * retrying in this example, so disconnect. Without this, the client
		 * will attempt to reconnect. */
    mosquitto_disconnect(mosq);
  }

  /* You may wish to set a flag here to indicate to your application that the
	 * client is now connected. */
}


/* set priority and scheduling of thread */
static void setprio(pthread_t id, int policy, int prio) {
  struct sched_param param;
  param.sched_priority = prio;
  if ((pthread_setschedparam(id, policy, &param)) != 0) {
    //	report_and_exit("change of thread priority and scheduling policy not possible");
    printf("problem to set priority and scheduling policy id: %ld\n", id);
  }
}


/* get thread info and print the info */
static void getprio(pthread_t id, const char *name) {
  int policy;
  struct sched_param param;
  printf("thread: %s,", name);
  printf(" id: %ld,", id);
  if ((pthread_getschedparam(id, &policy, &param)) == 0) {
    printf(" scheduling policy: ");
    switch (policy) {
      case SCHED_OTHER: printf("SCHED_OTHER,"); break;
      case SCHED_FIFO: printf("SCHED_FIFO, "); break;
      case SCHED_RR: printf("SCHED_RR, "); break;
      default: printf("unknown, "); break;
    }
    printf("priority: %d", param.sched_priority);
  }
  printf("\n");
}


/* Callback called when the client knows to the best of its abilities that a
 * PUBLISH has been successfully sent. For QoS 0 this means the message has
 * been completely written to the operating system. For QoS 1 this means we
 * have received a PUBACK from the broker. For QoS 2 this means we have
 * received a PUBCOMP from the broker. */
void on_mqtt_publish(struct mosquitto *mosq, void *obj, int mid) {
  /* endtime of WLAN transmission to influxdb */
  gettimeofday(&t2, NULL);
  /* Berechne die verbrauchte Zeit in Microsekunden */
  elapsedTime = ((t2.tv_sec * 1000000) + t2.tv_usec) - ((t0.tv_sec * 1000000) + t0.tv_usec);
  last_influxdb_transmission_time = elapsedTime / 1000;
  if (last_influxdb_transmission_time == 0) {
    last_influxdb_transmission_time = 1;
  }
  pthread_mutex_lock(&buffer_influx_mutex);
  buffer_in_influx_last_tt(last_influxdb_transmission_time);
  pthread_mutex_unlock(&buffer_influx_mutex);
}


void prep_msg_header_influxdb(void) {
  bzero((char *)&msg_header1, sizeof(msg_header1));
  strcat(msg_header1, "POST ");
  strcat(msg_header1, influxdb_pfad);
  strcat(msg_header1, " HTTP/1.1\r\nHost: ");
  strcat(msg_header1, influxdb_server);
  strcat(msg_header1, ":");
  strcat(msg_header1, influxdb_port);
  strcat(msg_header1, "\r\nUser-Agent: ");
  strcat(msg_header1, firmware_version);
  strcat(msg_header1, "/raspi-");
  strcat(msg_header1, raspi_id_strg);
  printf("raspi_id: raspi-%s\n", raspi_id_strg);
  strcat(msg_header1, "/");
  strcat(msg_header1, mac_strg);
  strcat(msg_header1, "\r\nAccept-Encoding: identity;q=1,chunked;q=0.1,*;q=0\r\nAuthorization: Basic ");

  bzero((char *)&msg_header2, sizeof(msg_header2));
  strcat(msg_header2, "\r\nConnection: close\r\nContent-Type: application/x-www-form-urlencoded\r\nX-Sensor: raspi-");
  strcat(msg_header2, raspi_id_strg);
  strcat(msg_header2, "\r\nX-MAC-ID: raspi-");
  strcat(msg_header2, mac_strg);
  strcat(msg_header2, "\r\nContent-Length: ");

  bzero((char *)&influxdb_hostname, sizeof(influxdb_hostname));
  strcat(influxdb_hostname, influxdb_server);
  strcat(influxdb_hostname, ":");
  strcat(influxdb_hostname, influxdb_port);

  bzero((char *)&influxdb_user_passwd, sizeof(influxdb_user_passwd));
  strcat(influxdb_user_passwd, influxdb_user);
  strcat(influxdb_user_passwd, ":");
  strcat(influxdb_user_passwd, influxdb_passwort);
}

void prep_msg_header_sc(void) {
  bzero((char *)&sc_header1, sizeof(sc_header1));
  strcat(sc_header1, "POST ");
  strcat(sc_header1, url_sc);
  strcat(sc_header1, " HTTP/1.1\r\nHost: ");
  strcat(sc_header1, host_sc);
  strcat(sc_header1, "\r\nUser-Agent: ");
  strcat(sc_header1, firmware_version);
  strcat(sc_header1, "/");
  strcat(sc_header1, raspi_id_strg);
  strcat(sc_header1, "/");
  strcat(sc_header1, mac_strg);
  strcat(sc_header1, "\r\nAccept-Encoding: identity;q=1,chunked;q=0.1,*;q=0\r\nConnection: close\r\n");
  strcat(sc_header1, "Content-Type: application/json\r\nX-Sensor: raspi-");
  strcat(sc_header1, raspi_id_strg);
  strcat(sc_header1, "\r\nX-MAC-ID: raspi-");
  strcat(sc_header1, mac_strg);
  strcat(sc_header1, "\r\nX-PIN: ");
  strcat(sc_header1, DNMS_API_PIN);
  strcat(sc_header1, "\r\nContent-Length: ");

  bzero((char *)&sc_hostname, sizeof(sc_hostname));
  strcat(sc_hostname, host_sc);
  strcat(sc_hostname, ":");
  strcat(sc_hostname, port_sc);
}

void prep_data_sc(void) {
  bzero((char *)&data_sc_1, sizeof(data_sc_1));
  strcat(data_sc_1, "{\"software_version\": \"");
  strcat(data_sc_1, firmware_version);
  strcat(data_sc_1, "\", \"sensordatavalues\":[{\"value_type\":\"noise_LAeq\",\"value\":\"");

  bzero((char *)&data_sc_2, sizeof(data_sc_2));
  strcat(data_sc_2, "\"},{\"value_type\":\"noise_LA_min\",\"value\":\"");

  bzero((char *)&data_sc_3, sizeof(data_sc_3));
  strcat(data_sc_3, "\"},{\"value_type\":\"noise_LA_max\",\"value\":\"");

  bzero((char *)&data_sc_4, sizeof(data_sc_4));
  strcat(data_sc_4, "\"}]}");
}


int get_mac(char *interface, char *mac_address) {
  int fd;
  struct ifreq ifr;
  char *iface = interface;
  unsigned char *mac = NULL;

  memset(&ifr, 0, sizeof(ifr));
  fd = socket(AF_INET, SOCK_STREAM, 0);
  ifr.ifr_addr.sa_family = AF_INET;
  strncpy(ifr.ifr_name, iface, IFNAMSIZ - 1);

  if (0 == ioctl(fd, SIOCGIFHWADDR, &ifr)) {
    mac = (unsigned char *)ifr.ifr_hwaddr.sa_data;
    close(fd);
    for (int i = 0; i < 6; i++) {
      mac_address[i] = mac[i];
    }
    return 0;
  } else {
    return 1;
  }
}


void report_and_exit(const char *msg) {
  perror(msg);
  ERR_print_errors_fp(stderr);
  exit(-1);
}


void init_ssl() {
#if OPENSSL_VERSION_NUMBER < 0x10100000L
  SSL_library_init();
#else
  OPENSSL_init_ssl(0, NULL);
#endif

  SSL_load_error_strings();

  method = TLS_client_method();
  if (NULL == method) {
    report_and_exit("TLS_client_method...");
  }
  ctx = SSL_CTX_new(method);
  if (NULL == ctx) {
    report_and_exit("SSL_CTX_new...");
  }
  SSL_CTX_set_min_proto_version(ctx, TLS1_2_VERSION);
}


void secure_connect(const char *hostname) {
  int res;

  init_ssl();

  bio = BIO_new_ssl_connect(ctx);
  if (NULL == bio) {
    report_and_exit("BIO_new_ssl_connect...");
  }
  ssl = NULL;

  /* link bio channel, SSL session, and server endpoint */

  sprintf(name, "%s", hostname);
  BIO_get_ssl(bio, &ssl);                 /* session */
  SSL_set_mode(ssl, SSL_MODE_AUTO_RETRY); /* robustness */

  BIO_set_conn_hostname(bio, name); /* prepare to connect */

  for (unsigned i = 0; i < 30; i++) {
    /* try to connect */
    res = BIO_do_connect(bio);
    if (res > 0) {
      break;
    }
    usleep(2000);
  }
  if (res <= 0) {
    printf("\nres BIO connect: %d\n", res);
    SSL_CTX_free(ctx);
    BIO_free(bio);
    report_and_exit("BIO_do_connect...");
  }
  /* secure connection established */
}


/* Print actual time to stdout  */
void print_time() {
  time(&sekunden);
  ts_print_1 = localtime(&sekunden);
  strftime(zeit_string_print, 80, "%d.%m.%Y %X ", ts_print_1);
  printf("%s ", zeit_string_print);
}


/* Timer for 2nd interval to start measurement thread */
void *measurement_2nd_interval_timer_function(void *ptr) {
  setprio(pthread_self(), SCHED_RR, prio_2nd_timer);
  if (output_thread_info) {
    getprio(pthread_self(), "measurement_2nd_interval_timer_thread");
  }

  // wait for start
  pthread_mutex_lock(&start_2nd_measurement_mutex);
  pthread_cond_wait(&start_2nd_measurement_cond, &start_2nd_measurement_mutex);
  pthread_mutex_unlock(&start_2nd_measurement_mutex);
  for (;;) {
    // Interval timer for 2nd interval
    usleep(measurement_2nd_interval_ms * 1000 - time_correction);
    pthread_mutex_lock(&new_2nd_measurement_mutex);
    pthread_cond_signal(&new_2nd_measurement_cond);
    pthread_mutex_unlock(&new_2nd_measurement_mutex);
  }
}


/* Measurement for 2nd interval */
void *measurement_2nd_interval_function(void *ptr) {
  int ret;

  setprio(pthread_self(), SCHED_RR, prio_2nd_measurement);
  if (output_thread_info) {
    getprio(pthread_self(), "measurement_2nd_interval_thread");
  }


  for (;;) {
    /* wait until cyclic time kick from main */
    pthread_mutex_lock(&new_2nd_measurement_mutex);
    pthread_cond_wait(&new_2nd_measurement_cond, &new_2nd_measurement_mutex);
    pthread_mutex_unlock(&new_2nd_measurement_mutex);

    /* lock DNMS access */
    pthread_mutex_lock(&dnms_mutex);
    /* start LAeq calculation in DNMS */
    dnms_error_2nd = false;
    if (dnms_calculate_leq_2nd() != 0) {
      dnms_error_2nd = true;
      print_time();
      printf("Error DNMS_CALCULATE_LEQ_2nd\n\n");
    } else {
      /* is data ready? */
      for (unsigned i = 0; i < 1000; i++) {
        ret = dnms_read_data_ready_2nd(&data_ready_2nd);
        if ((ret == 0) && (data_ready_2nd != 0)) {
          break;
        }
        usleep(20);
      }
    }

    if (!dnms_error_2nd) {
      if (dnms_read_leq(DNMS_CMD_READ_LEQ_2nd, &dnms_values) == 0) {
        last_value_dnms_laeq_2nd = dnms_values.leq_x + dnms_correction;
        if (last_value_dnms_laeq_2nd == 0) {
          dnms_error_2nd = true;
          print_time();
          printf("LAeq 2nd = 0!\n\n");
        }
        last_value_dnms_lamin_2nd = dnms_values.leq_x_min + dnms_correction;
        last_value_dnms_lamax_2nd = dnms_values.leq_x_max + dnms_correction;

        if (data_transmit_laeq_2nd_spectrum_to_influxdb || data_la_spec_2nd_output_on_terminal) {
          if (dnms_read_freq_spec(DNMS_CMD_READ_FFT_PART1_2nd, &dnms_values) == 0) {
            for (unsigned i = 0; i < 31; i++) {
              last_value_dnms_spectrum_2nd[i] = dnms_values.leq_freq_spec_x[i];
            }
          } else {
            dnms_error_2nd = true;
            print_time();
            printf("Error DNMS_CMD_READ_FFT_2nd\n\n");
          }
        }
      } else {
        dnms_error_2nd = true;
        print_time();
        printf("Error DNMS_CMD_READ_LEQ_2nd\n\n");
      }
      if (data_transmit_lzeq_2nd_to_influxdb || data_lzeq_2nd_output_on_terminal || data_lz_spec_2nd_output_on_terminal) {
        if (dnms_read_leq(DNMS_CMD_READ_LEQ_Z_2nd, &dnms_values) == 0) {
          last_value_dnms_lzeq_2nd = dnms_values.leq_x + dnms_correction;
          last_value_dnms_lzmin_2nd = dnms_values.leq_x_min + dnms_correction;
          last_value_dnms_lzmax_2nd = dnms_values.leq_x_max + dnms_correction;

          if (data_transmit_lzeq_2nd_spectrum_to_influxdb || data_lz_spec_2nd_output_on_terminal) {
            if (dnms_read_freq_spec(DNMS_CMD_READ_FFT_Z_PART1_2nd, &dnms_values) == 0) {
              for (unsigned i = 0; i < 31; i++) {
                last_value_dnms_z_spectrum_2nd[i] = dnms_values.leq_freq_spec_x[i];
              }
            } else {
              dnms_error = true;
              print_time();
              printf("Error DNMS_CMD_READ_FFT_Z_2nd\n\n");
            }
          }
        } else {
          dnms_error_2nd = true;
          print_time();
          printf("Error DNMS_CMD_READ_LEQ_2nd\n\n");
        }
      }
    }

    if (dnms_error_2nd) {
      close_i2c_dnms();
      open_dnms();
      print_time();
      printf("try to reset DNMS there was an Error interval 2nd\n\n");
      sleep(3);
      /* unlock DNMS access */
      pthread_mutex_unlock(&dnms_mutex);
    } else {
      /* unlock DNMS access */
      pthread_mutex_unlock(&dnms_mutex);

      /* timestamp  for this measurement*/
      gettimeofday(&tv_2nd, NULL);
      bzero((char *)&timestamp_2nd, sizeof(timestamp_2nd));
      bzero((char *)&timestamp_4_log_A_2nd, sizeof(timestamp_4_log_A_2nd));

      ns_2nd = (uint64_t)tv_2nd.tv_sec * 1000000000 + (uint64_t)tv_2nd.tv_usec * 1000;
      rawtime_2nd = ns_2nd / 1000000000;
      ts_print_1 = localtime(&rawtime_2nd);
      ts_print_2 = localtime(&tv_2nd.tv_sec);

      sprintf(timestamp_2nd, "%llu", ns_2nd);

      strftime(timestamp_4_log_A_2nd, 80, "%d.%m.%Y,", ts_print_1);  // for logging and printig

      sprintf(value_2_string, " %02d:%02d:%02d.%03ld, ", ts_print_2->tm_hour, ts_print_2->tm_min, ts_print_2->tm_sec, tv_2nd.tv_usec / 1000);
      strcat(timestamp_4_log_A_2nd, value_2_string);

      strcpy(timestamp_4_log_Z_2nd, timestamp_4_log_A_2nd);

      if (last_value_dnms_laeq_2nd >= threshold_2nd_interval_laeq_transmit) {
        /* retrigger counter */
        counter_threshold_2nd = number_transmissions_after_exceeding;
#ifdef gpio_switch
        /* set output if configured */
        if (switch_output_pin) {
          gpioWrite(gpio_output_pin, 1);
        }
#endif
      }

      if (counter_threshold_2nd > 0) {
        /* timestamp  for this measurement */
        time(&sekunden);

        /* format the string for influxdb */
        bzero((char *)&data_4_influxdb_2nd, sizeof(data_4_influxdb_2nd));

        strcat(data_4_influxdb_2nd, influxdb_messung);
        strcat(data_4_influxdb_2nd, ",node=raspi-");
        strcat(data_4_influxdb_2nd, raspi_id_strg);
        strcat(data_4_influxdb_2nd, " ");

        if (data_transmit_laeq_2nd_to_influxdb) {
          strcat(data_4_influxdb_2nd, "DNMS_noise_LAeq_2nd=");
          sprintf(value_2_string_2nd, "%.1f", last_value_dnms_laeq_2nd);
          strcat(data_4_influxdb_2nd, value_2_string_2nd);

          strcat(data_4_influxdb_2nd, ",DNMS_noise_LA_min_2nd=");
          sprintf(value_2_string_2nd, "%.1f", last_value_dnms_lamin_2nd);
          strcat(data_4_influxdb_2nd, value_2_string_2nd);

          strcat(data_4_influxdb_2nd, ",DNMS_noise_LA_max_2nd=");
          sprintf(value_2_string_2nd, "%.1f", last_value_dnms_lamax_2nd);
          strcat(data_4_influxdb_2nd, value_2_string_2nd);
        }

        if (data_transmit_laeq_2nd_spectrum_to_influxdb) {
          for (unsigned i = 0; i < 31; i++) {
            strcat(data_4_influxdb_2nd, terzen_2nd[i]);
            sprintf(value_2_string_2nd, "%.1f", last_value_dnms_spectrum_2nd[i]);
            strcat(data_4_influxdb_2nd, value_2_string_2nd);
          }
        }

        if (data_transmit_lzeq_2nd_to_influxdb) {
          if (data_transmit_laeq_2nd_spectrum_to_influxdb || data_transmit_laeq_2nd_to_influxdb) {
            strcat(data_4_influxdb_2nd, ",");
          }
          strcat(data_4_influxdb_2nd, "DNMS_noise_LZeq_2nd=");
          sprintf(value_2_string_2nd, "%.1f", last_value_dnms_lzeq_2nd);
          strcat(data_4_influxdb_2nd, value_2_string_2nd);

          strcat(data_4_influxdb_2nd, ",DNMS_noise_LZ_min_2nd=");
          sprintf(value_2_string_2nd, "%.1f", last_value_dnms_lzmin_2nd);
          strcat(data_4_influxdb_2nd, value_2_string_2nd);

          strcat(data_4_influxdb_2nd, ",DNMS_noise_LZ_max_2nd=");
          sprintf(value_2_string_2nd, "%.1f", last_value_dnms_lzmax_2nd);
          strcat(data_4_influxdb_2nd, value_2_string_2nd);
        }

        if (data_transmit_lzeq_2nd_spectrum_to_influxdb) {
          for (unsigned i = 0; i < 31; i++) {
            strcat(data_4_influxdb_2nd, terzen_z_2nd[i]);
            sprintf(value_2_string_2nd, "%.1f", last_value_dnms_z_spectrum_2nd[i]);
            strcat(data_4_influxdb_2nd, value_2_string_2nd);
          }
        }

        /* is transmission enebled or stopped ?? '*/
        if (transmission_enabled) {
          pthread_mutex_lock(&buffer_influx_mutex);
          if (buffer_in_influx((char *)data_4_influxdb_2nd, (char *)timestamp_2nd, dest_influxdb) == buffer_fail) {
            print_time();
            printf("buffer overflow, try to increase buffer!\n");
            fflush(stdout);
            exit(-1);
          }
          pthread_mutex_unlock(&buffer_influx_mutex);
        }
        counter_threshold_2nd--;  // count down to zero
        if (counter_threshold_2nd == 0) {
#ifdef gpio_switch
          /* is switch_output_pin set? than reset output pin */
          if (switch_output_pin) {
            gpioWrite(gpio_output_pin, 0);
          }
#endif
        }
      }
      fflush(stdout);
      pthread_mutex_lock(&new_data_2nd_mutex);
      if (transmission_enabled) {
        pthread_cond_broadcast(&new_data_2nd_cond);
      }
      pthread_mutex_unlock(&new_data_2nd_mutex);
    }
  }
}


void *print_ipc_and_log_1st_function(void *ptr) {
  setprio(pthread_self(), SCHED_RR, prio_print_ipc_and_log_1st);
  if (output_thread_info) {
    getprio(pthread_self(), "print_ipc_and_log_1st_thread");
  }
  for (;;) {
    /* wait until a 1st interval measurement is done and a signal/broadcast for new data arrives */
    pthread_mutex_lock(&new_data_1st_mutex);
    pthread_cond_wait(&new_data_1st_cond, &new_data_1st_mutex);
    pthread_mutex_unlock(&new_data_1st_mutex);

    if (data_laeq_1st_output_on_terminal || data_lzeq_1st_output_on_terminal || data_la_spec_1st_output_on_terminal || data_lz_spec_1st_output_on_terminal) {
      pthread_mutex_lock(&print_mutex);

      bzero((char *)&print_string_1st, sizeof(print_string_1st));

      sprintf((char *)&print_string_1st, "%s", timestamp_4_log_A_1st);

      if (data_laeq_1st_output_on_terminal || data_la_spec_1st_output_on_terminal) {  // LA values
        if (data_laeq_1st_output_on_terminal) {
          sprintf(part_string_1st, "1,A,%.1f,%.1f,%.1f",
                  last_value_dnms_laeq, last_value_dnms_lamin,
                  last_value_dnms_lamax);
          strcat(print_string_1st, part_string_1st);
        } else {
          strcat(print_string_1st, "1,A, , , ");
        }

        if (data_la_spec_1st_output_on_terminal) {
          for (unsigned i = 0; i < 31; i++) {
            sprintf(part_string_1st, ",%.1f", last_value_dnms_spectrum[i]);
            strcat(print_string_1st, part_string_1st);
          }
        }
        strcat(print_string_1st, "\n");  // new line

        // output on terminal configured ??
        if (data_on_terminal) {
          printf("%s", print_string_1st);
        }

        // write to named pipe configured ??
        if (data_transmit_via_pipe) {
          write(dnms_pipe_fd, print_string_1st, strlen(print_string_1st));
        }

        // data logging configured ??
        if (data_logging) {
          logging_write(print_string_1st, strlen(print_string_1st));
        }
      }

      bzero((char *)&print_string_1st, sizeof(print_string_1st));

      sprintf((char *)&print_string_1st, "%s", timestamp_4_log_Z_1st);

      if (data_lzeq_1st_output_on_terminal || data_lz_spec_1st_output_on_terminal) {  // LZ values
        if (data_lzeq_1st_output_on_terminal) {
          sprintf(part_string_1st, "1,Z,%.1f,%.1f,%.1f",
                  last_value_dnms_lzeq, last_value_dnms_lzmin,
                  last_value_dnms_lzmax);
          strcat(print_string_1st, part_string_1st);
        } else {
          strcat(print_string_1st, "1,Z, , , ");
        }

        if (data_lz_spec_1st_output_on_terminal) {
          for (unsigned i = 0; i < 31; i++) {
            sprintf(part_string_1st, ",%.1f", last_value_dnms_z_spectrum[i]);
            strcat(print_string_1st, part_string_1st);
          }
        }
        strcat(print_string_1st, "\n");  // new line

        // output on terminal configured ??
        if (data_on_terminal) {
          printf("%s", print_string_1st);
        }

        // write to named pipe configured ??
        if (data_transmit_via_pipe) {
          write(dnms_pipe_fd, print_string_1st, strlen(print_string_1st));
        }

        // data logging configured ??
        if (data_logging) {
          logging_write(print_string_1st, strlen(print_string_1st));
        }
      }

      fflush(stdout);
      pthread_mutex_unlock(&print_mutex);
    }
  }
}


void *print_ipc_and_log_2nd_function(void *ptr) {
  setprio(pthread_self(), SCHED_RR, prio_print_ipc_and_log_2nd);
  if (output_thread_info) {
    getprio(pthread_self(), "print_ipc_and_log_2nd_thread");
  }

  for (;;) {
    /* wait until a 2nd interval measurement is done and a signal/broadcast for new data arrives */
    pthread_mutex_lock(&new_data_2nd_mutex);
    pthread_cond_wait(&new_data_2nd_cond, &new_data_2nd_mutex);
    pthread_mutex_unlock(&new_data_2nd_mutex);

    if (data_laeq_2nd_output_on_terminal || data_lzeq_2nd_output_on_terminal || data_la_spec_2nd_output_on_terminal || data_lz_spec_2nd_output_on_terminal && (counter_threshold_2nd > 0)) {
      pthread_mutex_lock(&print_mutex);

      bzero((char *)&print_string_2nd, sizeof(print_string_2nd));

      sprintf((char *)&print_string_2nd, "%s", timestamp_4_log_A_2nd);

      if (data_laeq_2nd_output_on_terminal || data_la_spec_2nd_output_on_terminal) {  // LA values
        if (data_laeq_2nd_output_on_terminal) {
          sprintf(part_string_2nd, "2,A,%.1f,%.1f,%.1f",
                  last_value_dnms_laeq_2nd, last_value_dnms_lamin_2nd,
                  last_value_dnms_lamax_2nd);
          strcat(print_string_2nd, part_string_2nd);
        } else {
          strcat(print_string_2nd, "2,A, , , ");
        }

        if (data_la_spec_2nd_output_on_terminal) {
          for (unsigned i = 0; i < 31; i++) {
            sprintf(part_string_2nd, ",%.1f", last_value_dnms_spectrum_2nd[i]);
            strcat(print_string_2nd, part_string_2nd);
          }
        }
        strcat(print_string_2nd, "\n");  // new line

        // output on terminal configured ??
        if (data_on_terminal) {
          printf("%s", print_string_2nd);
        }

        // write to named pipe configured ??
        if (data_transmit_via_pipe) {
          write(dnms_pipe_fd, print_string_2nd, strlen(print_string_2nd));
        }

        // data logging configured ??
        if (data_logging) {
          logging_write(print_string_2nd, strlen(print_string_2nd));
        }
      }

      bzero((char *)&print_string_2nd, sizeof(print_string_2nd));

      sprintf((char *)&print_string_2nd, "%s", timestamp_4_log_Z_2nd);

      if (data_lzeq_2nd_output_on_terminal || data_lz_spec_2nd_output_on_terminal) {  // LZ values
        if (data_lzeq_2nd_output_on_terminal) {
          sprintf(part_string_2nd, "2,Z,%.1f,%.1f,%.1f",
                  last_value_dnms_lzeq_2nd, last_value_dnms_lzmin_2nd,
                  last_value_dnms_lzmax_2nd);
          strcat(print_string_2nd, part_string_2nd);
        } else {
          strcat(print_string_2nd, "2,Z, , , ");
        }

        if (data_lz_spec_2nd_output_on_terminal) {
          for (unsigned i = 0; i < 31; i++) {
            sprintf(part_string_2nd, ",%.1f", last_value_dnms_z_spectrum_2nd[i]);
            strcat(print_string_2nd, part_string_2nd);
          }
        }
        strcat(print_string_2nd, "\n");  // new line

        // output on terminal configured ??
        if (data_on_terminal) {
          printf("%s", print_string_2nd);
        }

        // write to named pipe configured ??
        if (data_transmit_via_pipe) {
          write(dnms_pipe_fd, print_string_2nd, strlen(print_string_2nd));
        }

        // data logging configured ??
        if (data_logging) {
          logging_write(print_string_2nd, strlen(print_string_2nd));
        }
      }

      fflush(stdout);
      pthread_mutex_unlock(&print_mutex);
    }
  }
}


/* if external start stop is configured this function will become active */
void *start_stop_function(void *ptr) {

  int loop_number = 0;

  setprio(pthread_self(), SCHED_RR, prio_start_stop);
  if (output_thread_info) {
    getprio(pthread_self(), "start_stop_thread");
  }

  while (1) {  // wait for message via named pipe in endless loop
    usleep(20000);
    if (read(start_stop_pipe_fd, start_stop_buffer, start_stop_buffer_size) == -1) {
      if (errno == EAGAIN) {
        // nothing to do
      } else {
        perror("read pipe");
        exit(EXIT_FAILURE);
      }
    } else {

      if (start_stop_buffer[0] == '0') {

        transmission_enabled = false;
      } else {
        if (start_stop_buffer[0] == '1') {

          transmission_enabled = true;
        }
      }
    }
  }
}


void *wlan_function(void *ptr) {
  int res;
  bool something_to_transmit;
  uint16_t transmit_again;

  setprio(pthread_self(), SCHED_RR, prio_wlan);
  if (output_thread_info) {
    getprio(pthread_self(), "wlan_thread");
  }

  for (;;) {
    something_to_transmit = false;
    transmit_again = 0;
    usleep(20000);


    /* check buffers, if there is something to transmit ? */
    pthread_mutex_lock(&buffer_influx_mutex);
    if (buffer_out_influx((char *)send_data, (char *)send_timestamp, &send_last_tt, &destination) == buffer_success) {
      something_to_transmit = true;
    } else {
      pthread_mutex_lock(&buffer_sc_mutex);
      if (buffer_out_sc((char *)send_data, (char *)send_timestamp, &send_last_tt, &destination) == buffer_success) {
        something_to_transmit = true;
      }
      pthread_mutex_unlock(&buffer_sc_mutex);
    }
    pthread_mutex_unlock(&buffer_influx_mutex);

    if (something_to_transmit) {

      /* ***** transmission to Sensor.Community ?? ***** */
      if (destination == dest_sc) {
        /* starttime of actual WLAN transmission to SC*/
        gettimeofday(&t1, NULL);
        /* https or http transmision ?? */
        if (sc_transmit_https) {
          secure_connect(sc_hostname);

          for (unsigned i = 0; i < 100; i++) {
            if ((res = BIO_puts(bio, send_data)) > 0) {
              break;
            }
            usleep(2000);
          }
          if (res <= 0) {
            report_and_exit("SC https error BIO_puts(bio, sc_msg)...");
          }
          usleep(50000);

          BIO_free_all(bio);
          SSL_CTX_free(ctx);
        } else {
          /* http Socket connection to Sensor.Community server  */
sc_again_http:
          transmit_again++;
          for (unsigned i = 0; i < 100; i++) {
            if ((bio = BIO_new(BIO_s_connect())) != NULL) {
              break;
            }
            usleep(2000);
          }
          if (bio == NULL) {
            if (transmit_again <= 10) {
              goto sc_again_http;
            } else {
              report_and_exit("SC http BIO new() failed...");
            }
          }

          BIO_set_conn_hostname(bio, sc_hostname);

          for (unsigned i = 0; i < 100; i++) {
            if ((res = BIO_do_connect(bio)) > 0) {
              break;
            }
            usleep(2000);
          }
          if (res <= 0) {
            if (transmit_again <= 10) {
              goto sc_again_http;
            } else {
              report_and_exit("SC http error connecting to Sensor.Community server ...");
            }
          }
          for (unsigned i = 0; i < 100; i++) {
            if ((res = BIO_puts(bio, send_data)) > 0) {
              break;
            }
            usleep(2000);
          }
          if (res <= 0) {
            report_and_exit("SC http error transmitting data to Sensor.Community server ...");
          }

          usleep(50000);

          /* close socket connection  */
          BIO_free_all(bio);
        }

        /* endtime of WLAN transmission to SC */
        gettimeofday(&t2, NULL);
        /* Berechne die verbrauchte Zeit in Microsekunden */
        elapsedTime = ((t2.tv_sec * 1000000) + t2.tv_usec) - ((t1.tv_sec * 1000000) + t1.tv_usec);
        last_sc_transmission_time = elapsedTime / 1000;
      }

      if (destination == dest_influxdb) { /* transmission to InfluxDB */
        /* starttime of actual WLAN transmission to InfluxDB*/
        gettimeofday(&t0, NULL);

        sprintf(value_2_string_wlan, "%ld ", send_last_tt);
        strcat(send_data, ",last_transmission_time=");
        strcat(send_data, value_2_string_wlan);
        strcat(send_data, send_timestamp);

        strcpy(send_data_mqtt, send_data);

        length_data_str = strlen(send_data);
        sprintf(str_of_length_data_str, "%d", length_data_str);
        bzero((char *)&msg, sizeof(msg));
        strcat(msg, msg_header1);
        encoded_user_passwd = b64_encode((const unsigned char *)influxdb_user_passwd, strlen(influxdb_user_passwd));
        strcat(msg, encoded_user_passwd);
        strcat(msg, msg_header2);
        strcat(msg, str_of_length_data_str);
        strcat(msg, msg_header3);
        strcat(msg, send_data);

        /*   ******** transmission to MQTT Broker ?? ************** */
        if (mqtt_transmit) {
          /* Publish the message
									 * mosq - our client instance
									 * *mid = NULL - we don't want to know what the message id for this message is
									 * mqtt_topic = "example/temperature" - the topic on which this message will be published
									 * strlen(send_data_mqtt) =  the length of data string to send in bytes
									 * send_data_mqtt = data string to send
									 * qos = the configured MQTT QoS
									 * retain = false - do not use the retained message feature for this message
									 */
          rc = mosquitto_publish(mosq, NULL, mqtt_topic, strlen(send_data_mqtt), send_data_mqtt, mqtt_qos, false);
          if (rc != MOSQ_ERR_SUCCESS) {
            /* timestamp  for this measurement*/
            bzero((char *)&mqtt_error_timestamp, sizeof(mqtt_error_timestamp));
            bzero((char *)&zeit_string_mqtt, sizeof(zeit_string_mqtt));
            gettimeofday(&mqtt_error_tv, NULL);
            /* Unix timestamp is UTC */
            /* Time for logging and print to terminal in readable format and localtime */
            /* day month year */
            /* hours, minutes, seconds and milliseconds */
            ns_mqtt = (uint64_t)mqtt_error_tv.tv_sec * 1000000000 + (uint64_t)mqtt_error_tv.tv_usec * 1000;
            rawtime_mqtt = ns_mqtt / 1000000000;
            ts_mqtt_1 = localtime(&rawtime_mqtt);
            ts_mqtt_2 = localtime(&mqtt_error_tv.tv_sec);
            sprintf(mqtt_error_timestamp, "%llu", ns_mqtt);         // this is the timestamp of MQTT error
            strftime(zeit_string_mqtt, 80, "%d.%m.%Y", ts_mqtt_1);  // for error output
            sprintf(value_2_string, " %02d:%02d:%02d.%03ld ", ts_mqtt_2->tm_hour, ts_mqtt_2->tm_min, ts_mqtt_2->tm_sec, mqtt_error_tv.tv_usec / 1000);
            strcat(zeit_string_mqtt, value_2_string);
            strcat(zeit_string_mqtt, "MQTT error publishing: ");
            strcat(zeit_string_mqtt, mosquitto_strerror(rc));
            fprintf(stderr, "%s\n", zeit_string_mqtt);
          }
        }

        /*   ******** transmission to InfluxDB  with https ??  ************** */
        if (influxdb_transmit_https) {
influx_again_https:
          transmit_again++;
          secure_connect(influxdb_hostname);

          for (unsigned i = 0; i < 100; i++) {
            if ((res = BIO_puts(bio, msg)) > 0) {
              break;
            }
            usleep(2000);
          }
          if (res <= 0) {
            if (transmit_again <= 10) {
              goto influx_again_https;
            } else {
              report_and_exit("InfluxDB https error BIO_puts(bio, msg)...");
            }
          }

          usleep(50000);

          BIO_free_all(bio);
          SSL_CTX_free(ctx);

          /* endtime of WLAN transmission to influxdb */
          gettimeofday(&t2, NULL);
          /* Berechne die verbrauchte Zeit in Microsekunden */
          elapsedTime = ((t2.tv_sec * 1000000) + t2.tv_usec) - ((t0.tv_sec * 1000000) + t0.tv_usec);
          last_influxdb_transmission_time = elapsedTime / 1000;
          if (last_influxdb_transmission_time == 0) {
            last_influxdb_transmission_time = 1;
          }
          pthread_mutex_lock(&buffer_influx_mutex);
          buffer_in_influx_last_tt(last_influxdb_transmission_time);
          pthread_mutex_unlock(&buffer_influx_mutex);
        }

        /*   ******** transmission to InfluxDB  with http ?? ************** */
        if (influxdb_transmit_http) {
influx_again_http:
          transmit_again++;
          /* Socket connection to InflluxDB server  */
          for (unsigned i = 0; i < 100; i++) {
            if ((bio = BIO_new(BIO_s_connect())) != NULL) {
              break;
            }
            usleep(2000);
          }
          if (bio == NULL) {
            if (transmit_again <= 10) {
              goto influx_again_http;
            } else {
              report_and_exit("InfluxDB http error BIO_new() failed ...");
            }
          }

          BIO_set_conn_hostname(bio, influxdb_hostname);

          for (unsigned i = 0; i < 100; i++) {
            if ((res = BIO_do_connect(bio)) > 0) {
              break;
            }
            usleep(2000);
          }
          if (res <= 0) {
            if (transmit_again <= 10) {
              goto influx_again_http;
            } else {
              report_and_exit("InfluxDB http error connecting to influxDB server ...");
            }
          }

          for (unsigned i = 0; i < 100; i++) {
            if ((res = BIO_puts(bio, msg)) > 0) {
              //														printf("\n%s\n", msg);  // only for test purposes
              break;
            }
            usleep(2000);
          }

          if (res <= 0) {
            if (transmit_again <= 10) {
              goto influx_again_http;
            } else {
              report_and_exit("InfluxDB http error sending data to influxDB server ...");
            }
          }

          usleep(50000);

          /* close socket connection  */
          BIO_free_all(bio);

          /* endtime of WLAN transmission to influxdb */
          gettimeofday(&t2, NULL);
          /* calculate used time for transmission */
          elapsedTime = ((t2.tv_sec * 1000000) + t2.tv_usec) - ((t0.tv_sec * 1000000) + t0.tv_usec);
          last_influxdb_transmission_time = elapsedTime / 1000;
          if (last_influxdb_transmission_time == 0) {
            last_influxdb_transmission_time = 1;
          }
          pthread_mutex_lock(&buffer_influx_mutex);
          buffer_in_influx_last_tt(last_influxdb_transmission_time);
          pthread_mutex_unlock(&buffer_influx_mutex);
        }
      }

      time(&time_wlan);
      ts_wlan = localtime(&time_wlan);
      strftime(zeit_string_wlan, 80, "%d.%m.%Y %X ", ts_wlan);
      if ((last_influxdb_transmission_time_to_terminal && (destination == dest_influxdb)) && (last_influxdb_transmission_time >= threshold_output_influxdb_ltt_to_terminal)) {
        printf("%s  ", zeit_string_wlan);
        printf("last transmission time to InfluxDB: %ld ms\n", last_influxdb_transmission_time);
      }

      if ((last_sc_transmission_time_to_terminal && (destination == dest_sc)) && (last_sc_transmission_time >= threshold_output_sc_ltt_to_terminal)) {
        printf("%s  ", zeit_string_wlan);
        printf("last transmission time to Sensor.Community: %ld ms\n", last_sc_transmission_time);
      }
    } else {
      // nothing to do
    }
    fflush(stdout);
  }
}

void *measurement_1st_interval_timer_function(void *ptr) {

  setprio(pthread_self(), SCHED_RR, prio_1st_timer);
  if (output_thread_info) {
    getprio(pthread_self(), "measurement_1st_interval_timer_thread");
  }
  // wait for start
  pthread_mutex_lock(&start_1st_measurement_mutex);
  pthread_cond_wait(&start_1st_measurement_cond, &start_1st_measurement_mutex);
  pthread_mutex_unlock(&start_1st_measurement_mutex);
  for (;;) {
    // Interval time for Sensor.Community
    usleep(measurement_1st_interval_ms * 1000 - time_correction);
    pthread_mutex_lock(&new_1st_measurement_mutex);
    pthread_cond_signal(&new_1st_measurement_cond);
    pthread_mutex_unlock(&new_1st_measurement_mutex);
  }
}


void *measurement_1st_interval_function(void *ptr) {
  int ret;

  setprio(pthread_self(), SCHED_RR, prio_1st_measurement);
  if (output_thread_info) {
    getprio(pthread_self(), "measurement_1st_interval_thread");
  }

  for (;;) {
    pthread_mutex_lock(&new_1st_measurement_mutex);
    pthread_cond_wait(&new_1st_measurement_cond, &new_1st_measurement_mutex);
    pthread_mutex_unlock(&new_1st_measurement_mutex);

    /* lock access to DNMS */
    pthread_mutex_lock(&dnms_mutex);

    /* start LAeq calculation in DNMS */
    dnms_error = false;
    if (dnms_calculate_leq() != 0) {
      dnms_error = true;
      print_time();
      printf("Error DNMS_CALCULATE_LEQ\n\n");
    } else {
      /* is data ready? */
      for (unsigned i = 0; i < 1000; i++) {
        ret = dnms_read_data_ready(&data_ready);
        if ((ret == 0) && (data_ready != 0)) {
          break;
        }
        usleep(20);
      }
    }

    if (!dnms_error) {
      if (dnms_read_leq(DNMS_CMD_READ_LEQ, &dnms_values) == 0) {
        last_value_dnms_laeq = dnms_values.leq_x + dnms_correction;
        if (last_value_dnms_laeq == 0) {
          dnms_error = true;
          print_time();
          printf("LAeq 1st = 0!\n");
        }
        last_value_dnms_lamin = dnms_values.leq_x_min + dnms_correction;
        last_value_dnms_lamax = dnms_values.leq_x_max + dnms_correction;

        if (data_transmit_laeq_1st_spectrum_to_influxdb || data_la_spec_1st_output_on_terminal) {
          if (dnms_read_freq_spec(DNMS_CMD_READ_FFT_PART1, &dnms_values) == 0) {
            for (unsigned i = 0; i < 31; i++) {
              last_value_dnms_spectrum[i] = dnms_values.leq_freq_spec_x[i];
            }
          } else {
            dnms_error = true;
            print_time();
            printf("Error DNMS_CMD_READ_FFT\n\n");
          }
        }
      } else {
        dnms_error = true;
        print_time();
        printf("Error DNMS_CMD_READ_LEQ\n\n");
      }

      if (data_transmit_lzeq_1st_to_influxdb || data_lzeq_1st_output_on_terminal || data_lz_spec_1st_output_on_terminal) {
        if (dnms_read_leq(DNMS_CMD_READ_LEQ_Z, &dnms_values) == 0) {
          last_value_dnms_lzeq = dnms_values.leq_x + dnms_correction;
          last_value_dnms_lzmin = dnms_values.leq_x_min + dnms_correction;
          last_value_dnms_lzmax = dnms_values.leq_x_max + dnms_correction;

          if (data_transmit_lzeq_1st_spectrum_to_influxdb || data_lz_spec_1st_output_on_terminal) {
            if (dnms_read_freq_spec(DNMS_CMD_READ_FFT_Z_PART1, &dnms_values) == 0) {
              for (unsigned i = 0; i < 31; i++) {
                last_value_dnms_z_spectrum[i] = dnms_values.leq_freq_spec_x[i];
              }
            } else {
              dnms_error = true;
              print_time();
              printf("Error DNMS_CMD_READ_FFT_Z\n\n");
            }
          }
        } else {
          dnms_error = true;
          print_time();
          printf("Error DNMS_CMD_READ_LEQ_Z\n\n");
        }
      }
    }

    if (dnms_error) {
      close_dnms();
      open_dnms();
      print_time();
      printf("try to reset DNMS there was an Error\n\n");
      sleep(3);
      /* unlock DNMS access */
      pthread_mutex_unlock(&dnms_mutex);
    } else {
      /* unlock DNMS access */
      pthread_mutex_unlock(&dnms_mutex);

      /* timestamp  for this measurement*/
      bzero((char *)&timestamp_1st, sizeof(timestamp_1st));
      bzero((char *)&timestamp_4_log_A_1st, sizeof(timestamp_4_log_A_1st));

      gettimeofday(&tv_1st, NULL);
      /* Unix timestamp for InfluxDB  is UTC */
      /* Time for logging and print to terminal in readable format and localtime */
      /* day month year */
      /* hours, minutes, seconds and milliseconds */
      ns_1st = (uint64_t)tv_1st.tv_sec * 1000000000 + (uint64_t)tv_1st.tv_usec * 1000;
      rawtime_1st = ns_1st / 1000000000;
      ts_print_1 = localtime(&rawtime_1st);
      ts_print_2 = localtime(&tv_1st.tv_sec);
      sprintf(timestamp_1st, "%llu", ns_1st);  // this is the timestamp for InfluxDB

      strftime(timestamp_4_log_A_1st, 80, "%d.%m.%Y,", ts_print_1);  // for logging and printig

      sprintf(value_2_string, " %02d:%02d:%02d.%03ld, ", ts_print_2->tm_hour, ts_print_2->tm_min, ts_print_2->tm_sec, tv_1st.tv_usec / 1000);
      strcat(timestamp_4_log_A_1st, value_2_string);

      strcpy(timestamp_4_log_Z_1st, timestamp_4_log_A_1st);

      /* **** transmit data to InfluxDB ?? */
      if (data_1st_to_influxdb) {
        /* format the string for influxdb  */
        bzero((char *)&data_4_transmit, sizeof(data_4_transmit));

        strcat(data_4_transmit, influxdb_messung);
        strcat(data_4_transmit, ",node=raspi-");
        strcat(data_4_transmit, raspi_id_strg);
        strcat(data_4_transmit, " ");
        if (data_transmit_laeq_1st_to_influxdb) {
          strcat(data_4_transmit, "DNMS_noise_LAeq=");
          sprintf(value_2_string, "%.1f", last_value_dnms_laeq);
          strcat(data_4_transmit, value_2_string);

          strcat(data_4_transmit, ",DNMS_noise_LA_min=");
          sprintf(value_2_string, "%.1f", last_value_dnms_lamin);
          strcat(data_4_transmit, value_2_string);

          strcat(data_4_transmit, ",DNMS_noise_LA_max=");
          sprintf(value_2_string, "%.1f", last_value_dnms_lamax);
          strcat(data_4_transmit, value_2_string);
        }

        if (data_transmit_laeq_1st_spectrum_to_influxdb) {
          for (unsigned i = 0; i < 31; i++) {
            strcat(data_4_transmit, terzen[i]);
            sprintf(value_2_string, "%.1f", last_value_dnms_spectrum[i]);
            strcat(data_4_transmit, value_2_string);
          }
        }

        if (data_transmit_lzeq_1st_to_influxdb) {
          if (data_transmit_laeq_1st_spectrum_to_influxdb || data_transmit_laeq_1st_to_influxdb) {
            strcat(data_4_transmit, ",");
          }
          strcat(data_4_transmit, "DNMS_noise_LZeq=");
          sprintf(value_2_string, "%.1f", last_value_dnms_lzeq);
          strcat(data_4_transmit, value_2_string);

          strcat(data_4_transmit, ",DNMS_noise_LZ_min=");
          sprintf(value_2_string, "%.1f", last_value_dnms_lzmin);
          strcat(data_4_transmit, value_2_string);

          strcat(data_4_transmit, ",DNMS_noise_LZ_max=");
          sprintf(value_2_string, "%.1f", last_value_dnms_lzmax);
          strcat(data_4_transmit, value_2_string);
        }

        if (data_transmit_lzeq_1st_spectrum_to_influxdb) {
          for (unsigned i = 0; i < 31; i++) {
            strcat(data_4_transmit, terzen_z[i]);
            sprintf(value_2_string, "%.1f", last_value_dnms_z_spectrum[i]);
            strcat(data_4_transmit, value_2_string);
          }
        }

        /* is transmission enabled or stopped ?? */
        if (transmission_enabled) {
          pthread_mutex_lock(&buffer_influx_mutex);
          if (buffer_in_influx((char *)data_4_transmit, (char *)timestamp_1st, dest_influxdb) == buffer_fail) {
            printf("buffer overflow for InfluxDB, try to increase buffer!\n");
            exit(-1);
          }
          pthread_mutex_unlock(&buffer_influx_mutex);
        }
      }

      /* **** transmit to Sensor.Community? If yes construct message for Sensor.Community?? */
      if (data_transmit_laeq_to_sc) {
        /* now format data string for Sensor.Community */
        bzero((char *)&data_4_transmit, sizeof(data_4_transmit));
        strcat(data_4_transmit, data_sc_1);
        sprintf(value_2_string, "%.1f", last_value_dnms_laeq);
        strcat(data_4_transmit, value_2_string);
        strcat(data_4_transmit, data_sc_2);
        sprintf(value_2_string, "%.1f", last_value_dnms_lamin);
        strcat(data_4_transmit, value_2_string);
        strcat(data_4_transmit, data_sc_3);
        sprintf(value_2_string, "%.1f", last_value_dnms_lamax);
        strcat(data_4_transmit, value_2_string);
        strcat(data_4_transmit, data_sc_4);

        /* now format header string for Sensor.Community */
        length_data_sc_str = strlen(data_4_transmit);
        sprintf(str_of_length_data_sc_str, "%d", length_data_sc_str);
        bzero((char *)&sc_msg, sizeof(sc_msg));
        strcat(sc_msg, sc_header1);
        strcat(sc_msg, str_of_length_data_sc_str);
        strcat(sc_msg, sc_header2);
        /* place data behind header */
        strcat(sc_msg, data_4_transmit);

        /* is transmission enabled or stopped ?? */
        if (transmission_enabled) {
          pthread_mutex_lock(&buffer_sc_mutex);
          if (buffer_in_sc((char *)sc_msg, (char *)timestamp_1st, dest_sc) == buffer_fail) {
            print_time();
            printf("buffer overflow for Sensor.Community try to increase buffer!\n");
            exit(-1);
          }
          pthread_mutex_unlock(&buffer_sc_mutex);
        }
      }
    }
    fflush(stdout);
    pthread_mutex_lock(&new_data_1st_mutex);
    if (transmission_enabled) {
      pthread_cond_broadcast(&new_data_1st_cond);
    }
    pthread_mutex_unlock(&new_data_1st_mutex);
  }
}


int get_config() {
  config_init(&cfg);
  /* Read the file. If there is an error, report it and exit. */
  if (!config_read_file(&cfg, "uhuuhu/dnms.conf")) {
    fprintf(stderr, "%s:%d - %s\n", config_error_file(&cfg),
            config_error_line(&cfg), config_error_text(&cfg));
    config_destroy(&cfg);
    return (EXIT_FAILURE);
  }

  config_lookup_int(&cfg, "waiting_time_after_start", &waiting_time_after_start);
  config_lookup_int(&cfg, "prio_1st_timer", &prio_1st_timer);
  config_lookup_int(&cfg, "prio_1st_measurement", &prio_1st_measurement);
  config_lookup_int(&cfg, "prio_2nd_timer", &prio_2nd_timer);
  config_lookup_int(&cfg, "prio_2nd_measurement", &prio_2nd_measurement);
  config_lookup_int(&cfg, "prio_wlan", &prio_wlan);
  config_lookup_int(&cfg, "prio_print_ipc_and_log_1st", &prio_print_ipc_and_log_1st);
  config_lookup_int(&cfg, "prio_print_ipc_and_log_2nd", &prio_print_ipc_and_log_2nd);
  config_lookup_int(&cfg, "prio_start_stop", &prio_start_stop);

  config_lookup_string(&cfg, "dev_name_dnms", &dev_name_dnms);
  config_lookup_string(&cfg, "interface_name", &interface_name);
  config_lookup_int(&cfg, "enable_wlan_or_lan", &enable_wlan_or_lan);

  config_lookup_string(&cfg, "dnms_microphone", &dnms_microphone);

  config_lookup_float(&cfg, "dnms_correction", &dnms_correction);

  config_lookup_int(&cfg, "enable_1st_interval", &enable_1st_interval);
  config_lookup_int(&cfg, "measurement_1st_interval_ms", &measurement_1st_interval_ms);
  config_lookup_int(&cfg, "enable_2nd_interval", &enable_2nd_interval);
  config_lookup_int(&cfg, "measurement_2nd_interval_ms", &measurement_2nd_interval_ms);
  config_lookup_int(&cfg, "threshold_2nd_interval_laeq_transmit", &threshold_2nd_interval_laeq_transmit);
  config_lookup_int(&cfg, "number_transmissions_after_exceeding", &number_transmissions_after_exceeding);
  config_lookup_int(&cfg, "switch_output_pin", &switch_output_pin);
  config_lookup_int(&cfg, "gpio_output_pin", &gpio_output_pin);
  config_lookup_int(&cfg, "start_on_full_minute", &start_on_full_minute);
  config_lookup_int(&cfg, "start_on_full_hour", &start_on_full_hour);
  config_lookup_int(&cfg, "time_correction", &time_correction);

  config_lookup_int(&cfg, "data_transmit_laeq_1st_to_influxdb", &data_transmit_laeq_1st_to_influxdb);
  config_lookup_int(&cfg, "data_transmit_lzeq_1st_to_influxdb", &data_transmit_lzeq_1st_to_influxdb);
  config_lookup_int(&cfg, "data_transmit_laeq_1st_spectrum_to_influxdb", &data_transmit_laeq_1st_spectrum_to_influxdb);
  config_lookup_int(&cfg, "data_transmit_lzeq_1st_spectrum_to_influxdb", &data_transmit_lzeq_1st_spectrum_to_influxdb);
  config_lookup_int(&cfg, "data_transmit_laeq_2nd_to_influxdb", &data_transmit_laeq_2nd_to_influxdb);
  config_lookup_int(&cfg, "data_transmit_lzeq_2nd_to_influxdb", &data_transmit_lzeq_2nd_to_influxdb);
  config_lookup_int(&cfg, "data_transmit_laeq_2nd_spectrum_to_influxdb", &data_transmit_laeq_2nd_spectrum_to_influxdb);
  config_lookup_int(&cfg, "data_transmit_lzeq_2nd_spectrum_to_influxdb", &data_transmit_lzeq_2nd_spectrum_to_influxdb);
  config_lookup_int(&cfg, "timestamp_to_influxdb", &timestamp_to_influxdb);
  config_lookup_int(&cfg, "influxdb_transmit_http", &influxdb_transmit_http);
  config_lookup_int(&cfg, "influxdb_transmit_https", &influxdb_transmit_https);
  config_lookup_int(&cfg, "influxdb_version_2", &influxdb_version_2);
  config_lookup_string(&cfg, "influxdb_server", &influxdb_server);
  config_lookup_string(&cfg, "influxdb_port", &influxdb_port);
  config_lookup_string(&cfg, "influxdb_pfad", &influxdb_pfad);
  config_lookup_string(&cfg, "influxdb_user", &influxdb_user);
  config_lookup_string(&cfg, "influxdb_passwort", &influxdb_passwort);
  config_lookup_string(&cfg, "influxdb_messung", &influxdb_messung);

  config_lookup_int(&cfg, "mqtt_transmit", &mqtt_transmit);
  config_lookup_string(&cfg, "mqtt_user", &mqtt_user);
  config_lookup_string(&cfg, "mqtt_passwort", &mqtt_passwort);
  config_lookup_string(&cfg, "mqtt_broker", &mqtt_broker);
  config_lookup_int(&cfg, "mqtt_port", &mqtt_port);
  config_lookup_int(&cfg, "mqtt_keepalive", &mqtt_keepalive);
  config_lookup_int(&cfg, "mqtt_qos", &mqtt_qos);
  config_lookup_string(&cfg, "mqtt_main_topic", &mqtt_main_topic);
  config_lookup_int(&cfg, "mqtt_use_id_as_sub_topic", &mqtt_use_id_as_sub_topic);

  config_lookup_int(&cfg, "data_transmit_laeq_to_sc", &data_transmit_laeq_to_sc);
  config_lookup_string(&cfg, "host_sc", &host_sc);
  config_lookup_string(&cfg, "port_sc", &port_sc);
  config_lookup_string(&cfg, "url_sc", &url_sc);
  config_lookup_string(&cfg, "DNMS_API_PIN", &DNMS_API_PIN);
  config_lookup_int(&cfg, "sc_transmit_https", &sc_transmit_https);

  config_lookup_int(&cfg, "data_transmit_via_pipe", &data_transmit_via_pipe);
  config_lookup_string(&cfg, "name_of_pipe", &name_of_pipe);

  config_lookup_string(&cfg, "start_stop_name_of_pipe", &start_stop_name_of_pipe);
  config_lookup_int(&cfg, "start_stop_extern", &start_stop_extern);

  config_lookup_int(&cfg, "data_on_terminal", &data_on_terminal);

  config_lookup_int(&cfg, "data_laeq_1st_output_on_terminal", &data_laeq_1st_output_on_terminal);
  config_lookup_int(&cfg, "data_la_spec_1st_output_on_terminal", &data_la_spec_1st_output_on_terminal);
  config_lookup_int(&cfg, "data_lzeq_1st_output_on_terminal", &data_lzeq_1st_output_on_terminal);
  config_lookup_int(&cfg, "data_lz_spec_1st_output_on_terminal", &data_lz_spec_1st_output_on_terminal);
  config_lookup_int(&cfg, "data_laeq_2nd_output_on_terminal", &data_laeq_2nd_output_on_terminal);
  config_lookup_int(&cfg, "data_la_spec_2nd_output_on_terminal", &data_la_spec_2nd_output_on_terminal);
  config_lookup_int(&cfg, "data_lzeq_2nd_output_on_terminal", &data_lzeq_2nd_output_on_terminal);
  config_lookup_int(&cfg, "data_lz_spec_2nd_output_on_terminal", &data_lz_spec_2nd_output_on_terminal);
  config_lookup_int(&cfg, "last_influxdb_transmission_time_to_terminal", &last_influxdb_transmission_time_to_terminal);
  config_lookup_int(&cfg, "threshold_output_influxdb_ltt_to_terminal", &threshold_output_influxdb_ltt_to_terminal);
  config_lookup_int(&cfg, "last_sc_transmission_time_to_terminal", &last_sc_transmission_time_to_terminal);
  config_lookup_int(&cfg, "threshold_output_sc_ltt_to_terminal", &threshold_output_sc_ltt_to_terminal);
  config_lookup_int(&cfg, "output_thread_info", &output_thread_info);

  config_lookup_int(&cfg, "data_logging", &data_logging);
  config_lookup_string(&cfg, "data_logging_directory", &data_logging_directory);

  //		config_destroy(&cfg);
  return (EXIT_SUCCESS);
}


int main(void) {
  int ret;
  int i;

  if (!(get_config() == EXIT_SUCCESS)) {
    /* Output Error and stop */
    report_and_exit("error reading configuration file: dnms.conf");
  }
  printf("\n");
  printf("Prog for Raspberry Pi to transmit noise data from a connected DNMS sensor\n ");
  printf("to Sensor.Community and/or to an influxDB database\n\n");

  printf("Wait %d seconds for everything to be ready!\n\n", waiting_time_after_start);
  sleep(waiting_time_after_start);  // wait some time, that erverything is settled in OS

  printf("Firmware version Raspberry Pi: %s\n\n", firmware_version);

  /* read mac address from system */
  for (i = 0; i < number_of_mac_loops; i++) {
    if (get_mac((char *)interface_name, (char *)mac_adr) == 0) {
      break;
    } else {
      sleep(1);  // wait some time
      if (i == (number_of_mac_loops - 1)) {
        printf("no Mac address found for given device name!\n");
        exit(0);
      }
    }
  }

  printf("MAC of selected Ethernet device %s is: %.2x:%.2x:%.2x:%.2x:%.2x:%.2x\n", interface_name, mac_adr[0], mac_adr[1], mac_adr[2], mac_adr[3], mac_adr[4], mac_adr[5]);
  bzero((char *)&mac_strg, sizeof(mac_strg));
  for (i = 0; i < 6; i++) {
    sprintf(value_2_string, "%2.x", mac_adr[i]);
    strcat(mac_strg, value_2_string);
  }
  mac_strg[12] = '\0';

  /* raspi ID is last three values of MAC as integer */
  raspi_id = (mac_adr[3] << 16) + (mac_adr[4] << 8) + mac_adr[5];
  sprintf(raspi_id_strg, "%d", raspi_id),

    /* Prepare message header for influxDB transmission */
    prep_msg_header_influxdb();

  /* Prepare message header and fixed part of data for Sensor.community transmission */
  prep_msg_header_sc();
  prep_data_sc();

  /* check if to start 1st measurement interval */
  /* it will be set active if transmission to Sensor.Community is set or 
		 * Transmission of 1st measurement to influxdb is set */
  if ((data_transmit_laeq_to_sc || data_transmit_laeq_1st_to_influxdb || data_transmit_lzeq_1st_to_influxdb || data_transmit_laeq_1st_spectrum_to_influxdb
       || data_transmit_lzeq_1st_spectrum_to_influxdb || data_laeq_1st_output_on_terminal || data_la_spec_1st_output_on_terminal || data_lzeq_1st_output_on_terminal
       || data_lz_spec_1st_output_on_terminal)
      && enable_1st_interval) {
    interval_1st_active = true;
  }

  /* check if to start 2nd measurement interval */
  /* it will be set active if transmission of 2nd measurement to influxdb is set */
  if ((data_transmit_laeq_2nd_to_influxdb || data_transmit_lzeq_2nd_to_influxdb || data_transmit_laeq_2nd_spectrum_to_influxdb
       || data_transmit_lzeq_2nd_spectrum_to_influxdb || data_laeq_2nd_output_on_terminal || data_la_spec_2nd_output_on_terminal
       || data_lzeq_2nd_output_on_terminal || data_lz_spec_2nd_output_on_terminal)
      && enable_2nd_interval) {
    interval_2nd_active = true;
  }


  /*  Open i2c bus */
  /*  setup DNMS   */
  open_dnms();

  sleep(3);

  /*  Firmware Version des DNMS auslesen */
  printf("DNMS firmware version: ");
  if (dnms_read_version(dnms_version) != 0) {
    printf("Error reading DNMS version!\n");
    printf("Check DNMS connection!\n");
    exit(-1);
  } else {
    dnms_version[DNMS_MAX_VERSION_LEN] = 0;
    printf("%s\n", dnms_version);
    if (dnms_version[13] == '3') {
      printf("Firmware includes FFT for spectrum output but  2nd measurement interval is not supported.\n");
      data_transmit_laeq_2nd_spectrum_to_influxdb = false;
      data_transmit_lzeq_2nd_spectrum_to_influxdb = false;
      data_la_spec_2nd_output_on_terminal = false;
      data_lz_spec_2nd_output_on_terminal = false;
      interval_2nd_active = false;
    } else {
      if (dnms_version[13] >= '4') {
        printf("Firmware includes FFT for spectrum output.\n");
        printf("Firmware includes 2nd measurement interval for transmission to influxDB.\n");
        if (dnms_version[13] == '5') {
          printf("Firmware includes calculation of Z-values and A-values.\n");
        }
        printf("\n");
      } else {
        printf("No support for spectrum output and/or 2nd measurement interval in DNMS firmware, \nfor Teensy4  you can upgrade to version 3 or 4!\n\n");
        data_transmit_laeq_2nd_spectrum_to_influxdb = false;
        data_transmit_laeq_1st_spectrum_to_influxdb = false;
        data_transmit_lzeq_2nd_spectrum_to_influxdb = false;
        data_transmit_lzeq_1st_spectrum_to_influxdb = false;
        data_la_spec_1st_output_on_terminal = false;
        data_lz_spec_1st_output_on_terminal = false;
        data_la_spec_2nd_output_on_terminal = false;
        data_lz_spec_2nd_output_on_terminal = false;
        interval_2nd_active = false;
      }
    }
  }

  /* set microphone depending on dnms.conf file, that is for firmware DNMS Version 5.3.x and above */
  if ((dnms_version[13] >= '5') && (dnms_version[15] >= '3')) {
    printf("set dnms_microphone:%s  :", dnms_microphone);
    if (strcmp(dnms_microphone, "ICS-43434") == 0) {
      if (dnms_set_ICS43434() == 0) {
        printf(" OK\n");
      } else {
        printf("Error setting ICS-43434 microphone, check it!\n");
      }
    } else {
      if (strcmp(dnms_microphone, "IM72D128") == 0) {
        if (dnms_set_IM72D128() == 0) {
          printf(" OK\n");
        } else {
          printf("Error setting IM72D128 microphone, check it!\n");
        }
      } else {
        printf("Wrong \"dnms_microphone\" configuration in dnms.conf, check it and change it otherwise ICS-43434 will be used!\n");
      }
    }

    /* print out dnms_correction value */
    printf("\ndnms_correction:%f\n\n", dnms_correction);
  }

#ifdef gpio_switch
  /* switching of GPIO PIN if 2nd measurement threshold is exceeded  */
  if (switch_output_pin) {
    gpioInitialise();
    gpioSetMode(gpio_output_pin, PI_OUTPUT);
    gpioWrite(gpio_output_pin, 0);
  }
#endif

  if (data_transmit_laeq_to_sc && enable_1st_interval) {
    measurement_1st_interval_ms = 150000; /*    *****   set the interval time for transmission to Sensor.Community to 150 seconds !! */
  }

  if (measurement_1st_interval_ms < 125) {
    measurement_1st_interval_ms = 125;
  }

  if (measurement_2nd_interval_ms < 125) {
    measurement_2nd_interval_ms = 125;
  }

  /* 1st interval active ? 	*/
  printf("1st interval enable is set to: ");
  printf("%s\n", interval_1st_active ? "true" : "false");
  if (interval_1st_active) {
    printf("1st interval measurement time is set to: %d ms\n", measurement_1st_interval_ms);
  }

  /* 2nd interval active ? 	*/
  printf("2nd interval enable is set to: ");
  printf("%s\n", interval_2nd_active ? "true" : "false");
  if (interval_2nd_active) {
    printf("2nd interval measurement time is set to: %d ms\n", measurement_2nd_interval_ms);
  }

  printf("\n");

  if (data_transmit_laeq_to_sc) {
    /* is transmission to Sensor.Community configured?  Output configuration on terminal */
    printf("Transmission to Sensor.Community of 1st interval values is set to: ");
    printf("%s\n", data_transmit_laeq_to_sc ? "true" : "false");

    /* output last Sensor.Community transmissons time on terminal */
    printf("Output last transmission time to Sensor.Community on terminal is set to: ");
    printf("%s\n", last_sc_transmission_time_to_terminal ? "true" : "false");

    if (last_sc_transmission_time_to_terminal) {
      printf("Threshold time for output last transmission time to Sensor.Community is set to: %d ms\n", threshold_output_sc_ltt_to_terminal);
    }
  }

  /* is transmission to influxdb configured? Output configuration on terminal */
  data_to_influxdb = (data_transmit_laeq_1st_to_influxdb || data_transmit_laeq_1st_spectrum_to_influxdb || data_transmit_laeq_2nd_to_influxdb || data_transmit_laeq_2nd_spectrum_to_influxdb || data_transmit_lzeq_1st_to_influxdb || data_transmit_lzeq_1st_spectrum_to_influxdb || data_transmit_lzeq_2nd_to_influxdb || data_transmit_lzeq_2nd_spectrum_to_influxdb) && (interval_1st_active || interval_2nd_active);
  data_1st_to_influxdb = (data_transmit_laeq_1st_to_influxdb || data_transmit_laeq_1st_spectrum_to_influxdb || data_transmit_lzeq_1st_to_influxdb || data_transmit_lzeq_1st_spectrum_to_influxdb) && interval_1st_active;
  data_2nd_to_influxdb = (data_transmit_laeq_2nd_to_influxdb || data_transmit_laeq_2nd_spectrum_to_influxdb || data_transmit_lzeq_2nd_to_influxdb || data_transmit_lzeq_2nd_spectrum_to_influxdb) && interval_2nd_active;
  if (data_to_influxdb) {
    printf("Transmission to InfluxDB  and/or MQTT broker is configured as follows:\n");

    printf("LAeq 1st is set to: ");
    printf("%s\n", data_transmit_laeq_1st_to_influxdb ? "true" : "false");
    printf("LZeq 1st is set to: ");
    printf("%s\n", data_transmit_lzeq_1st_to_influxdb ? "true" : "false");
    printf("LAeq spectrum 1st is set to: ");
    printf("%s\n", data_transmit_laeq_1st_spectrum_to_influxdb ? "true" : "false");
    printf("LZeq spectrum 1st is set to: ");
    printf("%s\n", data_transmit_lzeq_1st_spectrum_to_influxdb ? "true" : "false");

    if (interval_2nd_active) {
      printf("LAeq 2nd is set to: ");
      printf("%s\n", data_transmit_laeq_2nd_to_influxdb ? "true" : "false");
      printf("LZeq 2nd is set to: ");
      printf("%s\n", data_transmit_lzeq_2nd_to_influxdb ? "true" : "false");
      printf("LAeq spectrum 2nd is set to: ");
      printf("%s\n", data_transmit_laeq_2nd_spectrum_to_influxdb ? "true" : "false");
      printf("LZeq spectrum 2nd is set to: ");
      printf("%s\n", data_transmit_lzeq_2nd_spectrum_to_influxdb ? "true" : "false");
      printf("\n");
      if (data_transmit_laeq_2nd_to_influxdb) {
        /* output LAeq threshold for tansmission of 2nd measurement interval to influxDB and number of transmissions */
        printf("LAeq threshold for transmisson of 2nd measurement to InfluxDB and/or MQTT broker  is set to: %d LAeq\n", threshold_2nd_interval_laeq_transmit);
        printf("Number of transmissons of 2nd measurement interval after exceeding LAeq threshold is set to: %d\n", number_transmissions_after_exceeding);
      }
    }

    /* output last influxdb transmissons time on terminal */
    printf("Output last http/https transmisson time to InfluxDB on terminal is set to: ");
    printf("%s\n", last_influxdb_transmission_time_to_terminal ? "true" : "false");

    if (last_influxdb_transmission_time_to_terminal) {
      printf("Threshold time for last InfluxDB http/https transmission time is set to: %d ms\n", threshold_output_influxdb_ltt_to_terminal);
    }
    printf("\n");
    if (influxdb_transmit_https) {
      influxdb_transmit_http = false;  // if https is configured, no http!
      printf("https transmission to InfluxDB is configured\n");
    } else {
      if (influxdb_transmit_http) {
        printf("http transmission to InfluxDB is configured\n");
      }
    }
    printf("\n");

    if (mqtt_transmit) /* MQTT Broker transmission configured??  */
    {
      printf("Transmission to MQTT Broker is configured\n");
    }
    printf("\n");
  }

  /* output measurement values on terminal */
  if (data_transmit_via_pipe || data_on_terminal || data_logging) {
    if (interval_1st_active) {
      printf("Output LAeq 1st values on terminal, named pipe and/or data logging is set to: ");
      printf("%s\n", data_laeq_1st_output_on_terminal ? "true" : "false");
      printf("Output LZeq 1st values on terminal, named pipe and/or data logging is set to: ");
      printf("%s\n", data_lzeq_1st_output_on_terminal ? "true" : "false");
      printf("Output LAeq 1st spectrum values on terminal, named pipe and/or data logging is set to: ");
      printf("%s\n", data_la_spec_1st_output_on_terminal ? "true" : "false");
      printf("Output LZep 1st spectrum values on terminal, named pipe and/or data logging is set to: ");
      printf("%s\n", data_lz_spec_1st_output_on_terminal ? "true" : "false");
      printf("\n");
    }
    if (interval_2nd_active) {
      printf("Output LAeq 2nd values on terminal, named pipe and/or data logging is set to: ");
      printf("%s\n", data_laeq_2nd_output_on_terminal ? "true" : "false");
      printf("Output LZep 2nd values on terminal, named pipe and/or data logging is set to: ");
      printf("%s\n", data_lzeq_2nd_output_on_terminal ? "true" : "false");
      printf("Output LAeq 2nd spectrum values on terminal, named pipe and/or data logging is set to: ");
      printf("%s\n", data_la_spec_2nd_output_on_terminal ? "true" : "false");
      printf("Output LZep 2nd spectrum values on terminal, named pipe and/or data logging is set to: ");
      printf("%s\n", data_lz_spec_2nd_output_on_terminal ? "true" : "false");
      printf("\n");
    }
  }

  if (measurement_1st_interval_ms < 500) {
    data_transmit_laeq_1st_spectrum_to_influxdb = false;
    data_transmit_lzeq_1st_spectrum_to_influxdb = false;
    data_la_spec_1st_output_on_terminal = false;
    data_lz_spec_1st_output_on_terminal = false;
    if (measurement_1st_interval_ms < 125) {
      measurement_1st_interval_ms = 125;
    }
  }

  if (measurement_2nd_interval_ms < 500) {
    data_transmit_laeq_2nd_spectrum_to_influxdb = false;
    data_transmit_lzeq_2nd_spectrum_to_influxdb = false;
    data_la_spec_2nd_output_on_terminal = false;
    data_lz_spec_2nd_output_on_terminal = false;
    if (measurement_2nd_interval_ms < 125) {
      measurement_2nd_interval_ms = 125;
    }
  }


  /* MQTT transmission configured ?? */
  if (mqtt_transmit) {
    /* Required before calling other mosquitto functions */
    mosquitto_lib_init();
    /* Create a new client instance.
			 * id = NULL -> ask the broker to generate a client id for us
			 * clean session = true -> the broker should remove old sessions when we connect
			 * obj = NULL -> we aren't passing any of our private data for callbacks
			 */
    mosq = mosquitto_new(NULL, true, NULL);
    if (mosq == NULL) {
      fprintf(stderr, "MQTT error: Out of memory.\n");
      exit(-1);
    }
    /* Configure user and passwd for broker */
    rc = mosquitto_username_pw_set(mosq, mqtt_user, mqtt_passwort);
    if (rc != MOSQ_ERR_SUCCESS) {
      mosquitto_destroy(mosq);
      fprintf(stderr, "MQTT error: %s\n", mosquitto_strerror(rc));
      exit(-1);
    }
    /* Configure callbacks. This should be done before connecting ideally. */
    mosquitto_connect_callback_set(mosq, on_mqtt_connect);
    mosquitto_publish_callback_set(mosq, on_mqtt_publish);

    /* Connect to MQTT Broker with MQTT Port and keepalive time.
			 * This call makes the socket connection only, it does not complete the MQTT
			 * CONNECT/CONNACK flow, you should use mosquitto_loop_start() or
			 * mosquitto_loop_forever() for processing net traffic. */
    rc = mosquitto_connect(mosq, mqtt_broker, mqtt_port, mqtt_keepalive);
    if (rc != MOSQ_ERR_SUCCESS) {
      mosquitto_destroy(mosq);
      fprintf(stderr, "MQTT error: %s\n", mosquitto_strerror(rc));
      exit(-1);
    }
    /* Run the network loop in a background thread, this call returns quickly. */
    rc = mosquitto_loop_start(mosq);
    if (rc != MOSQ_ERR_SUCCESS) {
      mosquitto_destroy(mosq);
      fprintf(stderr, "MQTT error: %s\n", mosquitto_strerror(rc));
      exit(-1);
    }

    strcpy(mqtt_topic, mqtt_main_topic);
    if (mqtt_use_id_as_sub_topic) {
      strcat(mqtt_topic, "/raspi-");
      strcat(mqtt_topic, raspi_id_strg);
    }
  }

  /*  transmission via named pipe (FIFO) to other process ?? */
  if (data_transmit_via_pipe) {
    printf("named pipe transmission  is configured\n");
    umask(0);
    if (mkfifo(name_of_pipe, 0666) < 0) {
      if (errno != EEXIST) {  // does fifo exist??
        perror("mkfifo()");
        exit(EXIT_FAILURE);
      }
    }
    printf("named pipe is created or does exist with name: %s\n", name_of_pipe);
    dnms_pipe_fd = open(name_of_pipe, O_RDWR);
    if (dnms_pipe_fd == -1) {
      perror("open()");
      exit(EXIT_FAILURE);
    }
    printf("named pipe is opened with name: %s\n", name_of_pipe);
  }


  /*  transmission stoppable and startable based on external signal  via named pipe ?? */
  if (start_stop_extern) {
    transmission_enabled = false;
    umask(0);
    printf("\nexternal starting and stopping of transmission is configured\n");
    if (mkfifo(start_stop_name_of_pipe, O_RDWR | 0666) < 0) {
      if (errno != EEXIST) {  // does fifo exist??
        perror("mkfifo()");
        exit(EXIT_FAILURE);
      }
    }
    printf("named pipe for starting and stopping is created or does exist with name: %s\n", start_stop_name_of_pipe);
    start_stop_pipe_fd = open(start_stop_name_of_pipe, O_RDWR);
    if (start_stop_pipe_fd == -1) {
      perror("open()");
      exit(EXIT_FAILURE);
    }
    printf("named pipe for starting and stopping is opened with name: %s\n", start_stop_name_of_pipe);
  }

  /* data logging configured ?? */
  if (data_logging) {
    if (logging_init(data_logging_directory) == 0) {
      printf("\ndata logging  is configured\n");
      if (logging_file(data_logging_file_name) == 0) {
        printf("actual file for data logging is opened: %s\n", data_logging_file_name);
      } else {
        data_logging = false;
      }
    } else {
      data_logging = false;
    }
    if (!data_logging) {
      printf("\ndata logging could not be opened: error!\n");
    }
  }


  printf("\n");

  fflush(stdout);
  sleep(1);

  /* Create independent threads for dnms query, print and wlan*/

  if ((data_laeq_1st_output_on_terminal || data_lzeq_1st_output_on_terminal || data_la_spec_1st_output_on_terminal
       || data_lz_spec_1st_output_on_terminal)
      && interval_1st_active) {
    i_print_ipc_and_log_1st_thread = pthread_create(&print_ipc_and_log_1st_thread, NULL, print_ipc_and_log_1st_function, (void *)print_ipc_and_log_1st_message);
  }

  if ((data_laeq_2nd_output_on_terminal || data_lzeq_2nd_output_on_terminal || data_la_spec_2nd_output_on_terminal
       || data_lz_spec_2nd_output_on_terminal)
      && interval_2nd_active) {
    i_print_ipc_and_log_2nd_thread = pthread_create(&print_ipc_and_log_2nd_thread, NULL, print_ipc_and_log_2nd_function, (void *)print_ipc_and_log_2nd_message);
  }

  if (enable_wlan_or_lan) {
    i_wlan_thread = pthread_create(&wlan_thread, NULL, wlan_function, (void *)wlan_message);
  }

  if (interval_1st_active) {
    i_measurement_1st_interval_timer_thread = pthread_create(&measurement_1st_interval_timer_thread, NULL, measurement_1st_interval_timer_function, (void *)measurement_1st_timer_message);
    i_measurement_1st_interval_thread = pthread_create(&measurement_1st_interval_thread, NULL, measurement_1st_interval_function, (void *)measurement_1st_message);
  }

  if (interval_2nd_active) {
    i_measurement_2nd_interval_timer_thread = pthread_create(&measurement_2nd_interval_timer_thread, NULL, measurement_2nd_interval_timer_function, (void *)measurement_2nd_timer_message);
    i_measurement_2nd_interval_thread = pthread_create(&measurement_2nd_interval_thread, NULL, measurement_2nd_interval_function, (void *)measurement_2nd_message);
  }

  if (start_stop_extern) {
    i_start_stop_thread = pthread_create(&start_stop_thread, NULL, start_stop_function, (void *)start_stop_message);
  }

  if (start_on_full_minute || start_on_full_hour) {
    printf("Waiting for configured start on full minute or full hour - be patient :-)\n");
  }

  if (start_on_full_hour) {
    for (;;) {
      time(&minuten);
      ts_print_1 = localtime(&minuten);
      if (ts_print_1->tm_min == 0)
        break;
    }
  } else {
    if (start_on_full_minute) {
      for (;;) {
        time(&sekunden);
        ts_print_1 = localtime(&sekunden);
        if (ts_print_1->tm_sec == 0)
          break;
      }
    }
  }

  time(&sekunden);
  ts_print_1 = localtime(&sekunden);
  strftime(zeit_string_print, 80, "%d.%m.%Y %X ", ts_print_1);
  printf("\nStarting measurements at: %s\n\n", zeit_string_print);
  fflush(stdout);

  pthread_mutex_lock(&start_1st_measurement_mutex);
  pthread_cond_signal(&start_1st_measurement_cond);
  pthread_mutex_unlock(&start_1st_measurement_mutex);
  pthread_mutex_lock(&start_2nd_measurement_mutex);
  pthread_cond_signal(&start_2nd_measurement_cond);
  pthread_mutex_unlock(&start_2nd_measurement_mutex);

  // should never arrive here **** this is an error condition *****
  pthread_join(measurement_2nd_interval_timer_thread, NULL);
  pthread_join(measurement_2nd_interval_thread, NULL);
  pthread_join(print_ipc_and_log_1st_thread, NULL);
  pthread_join(print_ipc_and_log_2nd_thread, NULL);
  pthread_join(wlan_thread, NULL);
  pthread_join(measurement_1st_interval_timer_thread, NULL);
  pthread_join(measurement_1st_interval_thread, NULL);
  pthread_join(start_stop_thread, NULL);

  printf("measurement_2nd_interval_timer_thread returns: %d\n", i_measurement_2nd_interval_timer_thread);
  printf("measurement_2nd_interval_thread returns: %d\n", i_measurement_2nd_interval_thread);
  printf("print_thread  returns: %d\n", i_print_ipc_and_log_1st_thread);
  printf("print_and_log_2nd_thread  returns: %d\n", i_print_ipc_and_log_2nd_thread);
  printf("wlan_thread  returns: %d\n", i_wlan_thread);
  printf("measurement_1st_interval_timer_thread returns: %d\n", i_measurement_1st_interval_timer_thread);
  printf("measurement_1st_interval_thread  returns: %d\n", i_measurement_1st_interval_thread);
  printf("start_stop_thread returns: %d\n", i_start_stop_thread);

  if (mqtt_transmit) {
    mosquitto_lib_cleanup();
  }

  exit(0);
}
