/*
 * AudioDecimationFilter_F32.cpp
 *
 * Helmut Bitter, October 2021
 *
 * Realized for the DNMS project
 * 
 * Use at your own risk.
 *
*/

#ifndef _decimation_filter_f32_h
#define _decimation_filter_f32_h

#include "Arduino.h"
#include "AudioStream_F32.h"
#include <arm_math.h>

// Indicates that the code should just pass through the audio
// without any filtering (as opposed to doing nothing at all)
#define DECIMATION_F32_PASSTHRU ((const float32_t *) 1)


class AudioDecimationFilter_F32 : public AudioStream_F32
{
//GUI: inputs:1, outputs:1  //this line used for automatic generation of GUI node  
	public:
		AudioDecimationFilter_F32(void): AudioStream_F32(1,inputQueueArray), 
			coeff_p(DECIMATION_F32_PASSTHRU), n_coeffs(1), decim_factor(0), block_size(0), buffer_p(0), state_buffer_p(0) {	}
		AudioDecimationFilter_F32(const AudioSettings_F32 &settings): AudioStream_F32(1,inputQueueArray), 
			coeff_p(DECIMATION_F32_PASSTHRU), n_coeffs(1), decim_factor(0), block_size(0), buffer_p(0), state_buffer_p(0) {	}
			
		//initialize the FIR Decimation filter by giving it the filter coefficients
		void begin(const float32_t *cp, const uint16_t _n_coeffs, const uint8_t _decim_factor, const uint16_t _block_size, const float32_t *bp, const float32_t *sbp) {
			coeff_p = cp;
            n_coeffs = _n_coeffs;
            decim_factor = _decim_factor;
            block_size = _block_size;
            buffer_p = bp;
            state_buffer_p = sbp;
			
			// Initialize Decimation instance (ARM DSP Math Library)
			if (coeff_p && (coeff_p != DECIMATION_F32_PASSTHRU)) {
                arm_fir_decimate_init_f32 (&decim_inst, n_coeffs, decim_factor, (float32_t *) coeff_p, (float32_t *) state_buffer_p, block_size*decim_factor);
/*
                decim_inst.M = decim_factor;
                decim_inst.numTaps = n_coeffs;
                decim_inst.pCoeffs = (float32_t *) coeff_p;
                decim_inst.pState = (float32_t *) state_buffer_p;
                for (int idx = 0; idx < (n_coeffs + (block_size * decim_factor) - 1); idx++) {
                    *state_buffer_p++ = 0;
                }
*/
                cnt = 0;                
                blk_cnt = 0;
/*
				Serial.print("AudioDecimationFilter_F32: Decimation is initialized. n_coeffs: "); Serial.print(n_coeffs);
				Serial.print(", Block Size: "); Serial.println(block_size);
                Serial.print("decim_factor: "); Serial.println(decim_factor);
                Serial.print("1. coeff: "); Serial.print(*coeff_p, 15); Serial.print(" 2. coeff: "); Serial.print(*(coeff_p+1), 15);
                Serial.print(" 3. coeff: "); Serial.print(*(coeff_p+2), 15); Serial.print(" 4. coeff: "); Serial.println(*(coeff_p+3), 15);

                Serial.print("1. state_b: "); Serial.print(*state_buffer_p, 12);
                Serial.print(" 2. state_b: "); Serial.print(*(state_buffer_p+1), 12); 
                Serial.print(" 3. state_b: "); Serial.print(*(state_buffer_p+2), 12); 
                Serial.print(" 4. state_b: "); Serial.print(*(state_buffer_p+3), 12);
                Serial.print(" 5. state_b: "); Serial.print(*(state_buffer_p+4), 12); 
                Serial.print(" 6. state_b: "); Serial.print(*(state_buffer_p+5), 12);
                Serial.print(" 7. state_b: "); Serial.print(*(state_buffer_p+6), 12); 
                Serial.print(" 8. state_b: "); Serial.println(*(state_buffer_p+7), 12);

                Serial.print("number samples: "); Serial.println(block_size*decim_factor);
                
                Serial.print("coeff_p: "); Serial.print((int)coeff_p, HEX); Serial.print(" buffer_p: "); Serial.print((int)buffer_p, HEX);Serial.print(" state_buffer_p: "); Serial.println((int)state_buffer_p, HEX); 
*/  
			} else {
				//Serial.print("AudioDecimationFilter_F32: *** ERROR ***: Cound not initialize. n_coeffs: "); Serial.print(n_coeffs);
				//Serial.print(", Block Size: "); Serial.println(block_size);
				coeff_p = NULL;
			}
		}

		void end(void) {  coeff_p = NULL; }

		void update(void);

		
	private:
		audio_block_f32_t *inputQueueArray[1];

		// pointer to current coefficients or NULL or PASSTHRU
		const float32_t *coeff_p;
        float32_t *buffer_p;
        float32_t *state_buffer_p;
		uint16_t n_coeffs;
        uint8_t decim_factor;
        uint16_t block_size;
		int blk_cnt;
        float32_t *src_p;
        float32_t *dst_p;
        uint16_t cnt;
        uint16_t idx;

		// ARM DSP Math library filter instance
		arm_fir_decimate_instance_f32 decim_inst;
};


#endif


