/* Audio Library for Teensy 3.X
 * Copyright (c) 2014, Paul Stoffregen, paul@pjrc.com
 *
 * Development of this audio library was funded by PJRC.COM, LLC by sales of
 * Teensy and Audio Adaptor boards.  Please support PJRC's efforts to develop
 * open source software by purchasing Teensy or other PJRC products.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice, development funding notice, and this permission
 * notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 *
 * This version is for the DNMS project and has some specific changes
 *
 * The 24-bit input from the microphone is converted to 32-bit float
 * Only left channel input is supported, no right channel!
 *
 * Helmut Bitter, November 2020
 */

#include "input_i2s_f32.h"
#include "output_i2s_f32.h"
#include <arm_math.h>

DMAMEM __attribute__((aligned(32))) static uint32_t i2s_rx_buffer[2*AUDIO_BLOCK_SAMPLES];
//DMAMEM static uint32_t i2s_rx_buffer[2*AUDIO_BLOCK_SAMPLES];
audio_block_t * AudioInputI2S_F32::block_left = NULL;
audio_block_t * AudioInputI2S_F32::block_right = NULL;
audio_block_f32_t * AudioInputI2S_F32::block_left_f32 = NULL;
audio_block_f32_t * AudioInputI2S_F32::block_right_f32 = NULL;
uint16_t AudioInputI2S_F32::block_offset = 0;
bool AudioInputI2S_F32::update_responsibility = false;
DMAChannel AudioInputI2S_F32::dma(false);


float AudioInputI2S_F32::sample_rate_Hz = AUDIO_SAMPLE_RATE;
int AudioInputI2S_F32::audio_block_samples = AUDIO_BLOCK_SAMPLES;

#define transfer32bit true

void AudioInputI2S_F32::begin(void)
{
	dma.begin(true); // Allocate the DMA channel first

	// TODO: should we set & clear the I2S_RCSR_SR bit here?
	AudioOutputI2S_F32::sample_rate_Hz = sample_rate_Hz;
	AudioOutputI2S_F32::audio_block_samples = audio_block_samples;
	AudioOutputI2S_F32::config_i2s(transfer32bit);

#if defined(KINETISK)
	CORE_PIN13_CONFIG = PORT_PCR_MUX(4); // pin 13, PTC5, I2S0_RXD0
	dma.TCD->SADDR = (void *) ((uint32_t)&I2S0_RDR0);
	dma.TCD->SOFF = 0;
	dma.TCD->ATTR = DMA_TCD_ATTR_SSIZE(2) | DMA_TCD_ATTR_DSIZE(2);
	dma.TCD->NBYTES_MLNO = 4;
	dma.TCD->SLAST = 0;
	dma.TCD->DADDR = i2s_rx_buffer;
	dma.TCD->DOFF = 4;
	dma.TCD->CITER_ELINKNO = sizeof(i2s_rx_buffer) / 4;
	dma.TCD->DLASTSGA = -sizeof(i2s_rx_buffer);
	dma.TCD->BITER_ELINKNO = sizeof(i2s_rx_buffer) / 4;
	dma.TCD->CSR = DMA_TCD_CSR_INTHALF | DMA_TCD_CSR_INTMAJOR;
	dma.triggerAtHardwareEvent(DMAMUX_SOURCE_I2S0_RX);

	I2S0_RCSR |= I2S_RCSR_RE | I2S_RCSR_BCE | I2S_RCSR_FRDE | I2S_RCSR_FR;
	I2S0_TCSR |= I2S_TCSR_TE | I2S_TCSR_BCE; // TX clock enable, because sync'd to TX

#elif defined(__IMXRT1062__)
	CORE_PIN8_CONFIG  = 3;  //1:RX_DATA0
	IOMUXC_SAI1_RX_DATA0_SELECT_INPUT = 2;

	dma.TCD->SADDR = (void *)((uint32_t)&I2S1_RDR0);
	dma.TCD->SOFF = 0;
	dma.TCD->ATTR = DMA_TCD_ATTR_SSIZE(2) | DMA_TCD_ATTR_DSIZE(2);
	dma.TCD->NBYTES_MLNO = 4;
	dma.TCD->SLAST = 0;
	dma.TCD->DADDR = i2s_rx_buffer;
	dma.TCD->DOFF = 4;
	dma.TCD->CITER_ELINKNO = sizeof(i2s_rx_buffer) / 4;
	dma.TCD->DLASTSGA = -sizeof(i2s_rx_buffer);
	dma.TCD->BITER_ELINKNO = sizeof(i2s_rx_buffer) / 4;
	dma.TCD->CSR = DMA_TCD_CSR_INTHALF | DMA_TCD_CSR_INTMAJOR;
	dma.triggerAtHardwareEvent(DMAMUX_SOURCE_SAI1_RX);

	I2S1_RCSR = I2S_RCSR_RE | I2S_RCSR_BCE | I2S_RCSR_FRDE | I2S_RCSR_FR;

#endif

	update_responsibility = update_setup();
	dma.enable();
	dma.attachInterrupt(isr);
};


void AudioInputI2S_F32::isr(void)
{
	uint32_t daddr, offset;
	const int32_t *src, *end;
	audio_block_f32_t *left_f32;
//  audio_block_f32_t *right_f32;
  float32_t *dest_left_f32;
//  float32_t *dest_right_f32;

#define I24_TO_F32_NORM_FACTOR (1.19209290E-7)                // which is 1 / 8 388 608 

#if defined(KINETISK) || defined(__IMXRT1062__)
	daddr = (uint32_t)(dma.TCD->DADDR);
	dma.clearInterrupt();

	if (daddr < (uint32_t)i2s_rx_buffer + sizeof(i2s_rx_buffer) / 2) {	
		// DMA is receiving to the first half of the buffer
		// need to remove data from the second half
		src = (int32_t *)&i2s_rx_buffer[audio_block_samples];
		end = (int32_t *)&i2s_rx_buffer[audio_block_samples*2];
		if (AudioInputI2S_F32::update_responsibility) AudioStream_F32::update_all();
	} else {
		// DMA is receiving to the second half of the buffer
		// need to remove data from the first half
		src = (int32_t *)&i2s_rx_buffer[0];
		end = (int32_t *)&i2s_rx_buffer[audio_block_samples];
	}
 
  left_f32 = block_left_f32;
//  right_f32 = block_right_f32;
//	if (left_f32 != NULL && right_f32 != NULL) {
	if (left_f32 != NULL) {
		offset = AudioInputI2S_F32::block_offset;
		if (offset <= (uint32_t) audio_block_samples/2) {
      dest_left_f32 = &(left_f32->data[offset]);
//      dest_right_f32 = &(right_f32->data[offset])     
			AudioInputI2S_F32::block_offset = offset + audio_block_samples/2;
      arm_dcache_delete((void*)src, sizeof(i2s_rx_buffer) / 2);
			do {
        *dest_left_f32++ = ((float32_t)((*src++)>>8)) * I24_TO_F32_NORM_FACTOR;
//        *dest_right_f32++ = ((float32_t)((*src++)>>8)) * I24_TO_F32_NORM_FACTOR;
        (*src++);  // important increase address even if right channel is skipped
			} while (src < end);
		}
	}
#endif
}


#define I16_TO_F32_NORM_FACTOR (3.051757812500000E-05)  //which is 1/32768 
void AudioInputI2S_F32::convert_i16_to_f32( int16_t *p_i16, float32_t *p_f32, int len) {
  for (int i=0; i<len; i++) { 
    *p_f32++ = ((float32_t)(*p_i16++)) * I16_TO_F32_NORM_FACTOR;
  }
}


void AudioInputI2S_F32::update(void)
{
  audio_block_f32_t *new_left_f32=NULL, *out_left_f32=NULL;
//  audio_block_f32_t *new_right_f32=NULL, *out_right_f32=NULL;

	// allocate 2 new blocks, but if one fails, allocate neither
	new_left_f32 = allocate_f32();
//  new_right_f32 = allocate_f32();
//	if (new_left_f32 != NULL) {
//		new_right_f32 = allocate_f32();
//		if (new_right_f32 == NULL) {
//			release(new_left_f32);
//			new_left_f32 = NULL;
//		}
//	}
	__disable_irq();

	if (block_offset >= audio_block_samples) {
		// the DMA filled 2 blocks, so grab them and get the
		// 2 new blocks to the DMA, as quickly as possible
		out_left_f32 = block_left_f32;
		block_left_f32 = new_left_f32;   
//		out_right_f32 = block_right_f32;
//		block_right_f32 = new_right_f32;
		block_offset = 0;
    __enable_irq();
	
		// then transmit the DMA's former blocks
		
	  //transmit the f32 data!
    AudioStream_F32::transmit(out_left_f32,0);
//		AudioStream_F32::transmit(out_right_f32,1);
		AudioStream_F32::release(out_left_f32);
//		AudioStream_F32::release(out_right_f32);

	} else if (new_left_f32 != NULL) {
		// the DMA didn't fill blocks, but we allocated blocks
		if (block_left_f32 == NULL) {
			// the DMA doesn't have any blocks to fill, so
			// give it the ones we just allocated
			block_left_f32 = new_left_f32;
//			block_right_f32 = new_right_f32;
			block_offset = 0;
			__enable_irq();
		} else {     
			// the DMA already has blocks, doesn't need these
			__enable_irq();
      AudioStream_F32::release(new_left_f32);
//      AudioStream_F32::release(new_right_f32);
		}
	} else {
		// The DMA didn't fill blocks, and we could not allocate
		// memory... the system is likely starving for memory!
		// Sadly, there's nothing we can do.
		__enable_irq();
	}
}





