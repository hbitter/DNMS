/*
 * AudioDecimationFilter_F32.cpp
 *
 * Helmut Bitter, October 2021
 *
 * Realized for the DNMS project
 * 
 * Use at your own risk.
 *
*/

#include "AudioDecimationFilter_F32.h"


void AudioDecimationFilter_F32::update(void)
{
  audio_block_f32_t *block, *block_new;

  block = AudioStream_F32::receiveReadOnly_f32();
  if (!block) {
    return;
  }

  // If there's no coefficient table, give up.  
  if (coeff_p == NULL) {
    AudioStream_F32::release(block);
    return;
  }

  // do passthru
  if (coeff_p == DECIMATION_F32_PASSTHRU) {
    // Just passthrough
    AudioStream_F32::transmit(block);
    AudioStream_F32::release(block);
    return;
  }
  // copy block from audio_block to decimation buffer
  src_p = block->data;
  dst_p = buffer_p + (blk_cnt * block_size);
  //Serial.print("src_p: "); Serial.print((int)src_p, HEX); Serial.print("  dst_p: "); Serial.println((int)dst_p, HEX);
  for (idx = 0; idx < block_size; ++idx) {
    *dst_p++ = *src_p++;
  }
  // increase block count
  ++blk_cnt;
  if (blk_cnt == 32) {
    // get a new block for decimation output and do filtering and decimation
	block_new = AudioStream_F32::allocate_f32();
	if (block_new) {
	  arm_fir_decimate_f32(&decim_inst, buffer_p, block_new->data, block_size * decim_factor);
      cnt++;
           
	  block_new->length = block->length;
      //Serial.print("  block->length: "); Serial.println(block->length);
      //transmit the data
	  AudioStream_F32::transmit(block_new); // send the Decimation output
      AudioStream_F32::release(block_new);
      blk_cnt = 0;
	}
  }
  AudioStream_F32::release(block);
}
